<?php
// TuFarma/data/rut.php

/**
 * Normaliza RUT a formato estándar: 12345678-9
 * - Quita puntos/espacios
 * - Acepta con o sin guión
 * - DV en mayúscula (K)
 */
function rut_normalize(string $rut): string {
    $rut = strtoupper(trim($rut));
    $rut = str_replace([".", " ", "\t", "\n", "\r"], "", $rut);

    if ($rut === "") return "";

    if (strpos($rut, "-") !== false) {
        [$num, $dv] = array_pad(explode("-", $rut, 2), 2, "");
    } else {
        $num = substr($rut, 0, -1);
        $dv  = substr($rut, -1);
    }

    $num = preg_replace("/\D+/", "", $num);
    $dv  = preg_replace("/[^0-9K]/", "", $dv);

    if ($num === "" || $dv === "") return "";
    return $num . "-" . $dv;
}

/**
 * DV calculado del número
 */
function rut_calc_dv(string $num): string {
    $num = preg_replace("/\D+/", "", $num);
    if ($num === "") return "";

    $suma = 0;
    $mul = 2;

    for ($i = strlen($num) - 1; $i >= 0; $i--) {
        $suma += intval($num[$i]) * $mul;
        $mul++;
        if ($mul > 7) $mul = 2;
    }

    $res = 11 - ($suma % 11);
    if ($res === 11) return "0";
    if ($res === 10) return "K";
    return (string)$res;
}

/**
 * Valida RUT completo (DV correcto)
 */
function rut_is_valid(string $rut): bool {
    $norm = rut_normalize($rut);
    if ($norm === "") return false;

    [$num, $dv] = explode("-", $norm, 2);
    if ($num === "" || $dv === "") return false;

    return strtoupper($dv) === rut_calc_dv($num);
}

/**
 * RUT compacto CON DV, sin puntos/guión: 123456789
 * Esto es lo que usaremos para comparar en la BD.
 */
function rut_compact(string $rut): string {
    $norm = rut_normalize($rut);
    if ($norm === "") return "";
    return str_replace("-", "", $norm); // num + dv
}
