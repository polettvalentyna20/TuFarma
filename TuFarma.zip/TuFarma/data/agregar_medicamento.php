<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rut = trim($_POST['rut']);
    $nombre = trim($_POST['nombre']);
    $estado = trim($_POST['estado']);
    $fecha_ultimo_retiro = $_POST['fecha_ultimo_retiro'];
    $fecha_proximo_retiro = $_POST['fecha_proximo_retiro'];
    $cantidad = intval($_POST['cantidad']);
    $gramaje = trim($_POST['gramaje']);

    // Buscar paciente por RUT
    $stmt = $conexion->prepare("SELECT id FROM pacientes WHERE rut=?");
    $stmt->bind_param("s", $rut);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        $error = "Paciente no encontrado";
    } else {
        $paciente = $res->fetch_assoc();
        $paciente_id = $paciente['id'];

        $stmt2 = $conexion->prepare("INSERT INTO medicamentos (paciente_id, nombre, estado, fecha_ultimo_retiro, fecha_proximo_retiro, cantidad, gramaje) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt2->bind_param("issssis", $paciente_id, $nombre, $estado, $fecha_ultimo_retiro, $fecha_proximo_retiro, $cantidad, $gramaje);

        if ($stmt2->execute()) {
            $mensaje = "Medicamento registrado correctamente";
        } else {
            $error = "Error al registrar medicamento";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Medicamento</title>
</head>
<body>
<h2>Agregar Medicamento</h2>

<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
<?php if (isset($mensaje)) echo "<p style='color:green;'>$mensaje</p>"; ?>

<form method="post">
    RUT del paciente: <input type="text" name="rut" placeholder="12345678-9"><br><br>
    Nombre del medicamento: <input type="text" name="nombre"><br><br>
    Estado:
    <select name="estado">
        <option value="Disponible">Disponible</option>
        <option value="En preparación">En preparación</option>
        <option value="No disponible">No disponible</option>
    </select><br><br>
    Fecha último retiro: <input type="date" name="fecha_ultimo_retiro"><br><br>
    Fecha próximo retiro: <input type="date" name="fecha_proximo_retiro"><br><br>
    Cantidad retirada: <input type="number" name="cantidad" min="1"><br><br>
    Gramaje: <input type="text" name="gramaje" placeholder="50 mg"><br><br>
    <button type="submit">Registrar Medicamento</button>
</form>
</body>
</html>

