<?php
// TuFarma/data/audit.php

function audit_table_exists(mysqli $conn): bool {
    $res = $conn->query("SHOW TABLES LIKE 'auditoria'");
    return $res && $res->num_rows > 0;
}

function audit_log(mysqli $conn, ?int $adminId, string $accion, ?string $rut = null, ?string $detalle = null): void {
    // Si no existe tabla, no hacemos nada (no rompemos el sistema)
    if (!audit_table_exists($conn)) return;

    $ip = $_SERVER["REMOTE_ADDR"] ?? null;
    $ua = $_SERVER["HTTP_USER_AGENT"] ?? null;

    $stmt = $conn->prepare("
    INSERT INTO auditoria (admin_id, accion, rut, detalle, ip, user_agent)
    VALUES (?, ?, ?, ?, ?, ?)
  ");
    $stmt->bind_param(
        "isssss",
        $adminId,
        $accion,
        $rut,
        $detalle,
        $ip,
        $ua
    );
    $stmt->execute();
}

