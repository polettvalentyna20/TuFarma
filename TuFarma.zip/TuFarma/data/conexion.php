<?php
// TuFarma/data/conexion.php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host = "localhost";
$user = "root";
$pass = "root";   // en MAMP suele ser root/root (ajusta si el tuyo es distinto)
$db   = "tufarma";

$conn = new mysqli($host, $user, $pass, $db);
$conn->set_charset("utf8mb4");





