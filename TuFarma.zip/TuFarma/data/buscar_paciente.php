<?php
require "../conexion.php";

$rut = trim($_GET["rut"] ?? "");

if ($rut === "") {
    echo "Ingrese un RUT válido";
    exit;
}

$stmt = $conexion->prepare("SELECT id, nombre FROM pacientes WHERE rut=?");
$stmt->bind_param("s", $rut);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo "Paciente no encontrado";
    exit;
}

$paciente = $res->fetch_assoc();

$stmt2 = $conexion->prepare("
    SELECT nombre, estado, fecha_proximo_retiro 
    FROM medicamentos 
    WHERE paciente_id=?
");
$stmt2->bind_param("i", $paciente["id"]);
$stmt2->execute();
$meds = $stmt2->get_result();

echo "<h3>Paciente: {$paciente['nombre']}</h3>";

if ($meds->num_rows === 0) {
    echo "<p>No hay medicamentos registrados</p>";
    exit;
}

echo "<ul>";
while ($m = $meds->fetch_assoc()) {
    echo "<li><strong>{$m['nombre']}</strong> – {$m['estado']} (Retiro: {$m['fecha_proximo_retiro']})</li>";
}
echo "</ul>";
