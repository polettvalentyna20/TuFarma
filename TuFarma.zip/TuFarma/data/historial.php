<?php
include 'conexion.php';

if (!isset($_POST['rut'])) {
    exit;
}

$rut = trim($_POST['rut']);

$stmt = $conexion->prepare("SELECT id, nombre FROM pacientes WHERE rut=?");
$stmt->bind_param("s", $rut);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo "<p style='color:red'>Paciente no encontrado</p>";
    exit;
}

$paciente = $res->fetch_assoc();

$stmt2 = $conexion->prepare("SELECT * FROM medicamentos WHERE paciente_id=?");
$stmt2->bind_param("i", $paciente['id']);
$stmt2->execute();
$meds = $stmt2->get_result();

echo "<h3>{$paciente['nombre']}</h3>";

if ($meds->num_rows === 0) {
    echo "<p>No hay medicamentos registrados</p>";
    exit;
}

echo "<table border='1' cellpadding='5'>
<tr>
<th>Medicamento</th>
<th>Estado</th>
<th>Último retiro</th>
<th>Próximo retiro</th>
<th>Cantidad</th>
<th>Gramaje</th>
</tr>";

while ($m = $meds->fetch_assoc()) {
    echo "<tr>
        <td>{$m['nombre']}</td>
        <td>{$m['estado']}</td>
        <td>{$m['fecha_ultimo_retiro']}</td>
        <td>{$m['fecha_proximo_retiro']}</td>
        <td>{$m['cantidad']}</td>
        <td>{$m['gramaje']}</td>
    </tr>";
}
echo "</table>";

