<?php
include "conexion.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $rut = trim($_POST["rut"] ?? "");
    $nombre = trim($_POST["nombre"] ?? "");

    if ($rut === "" || $nombre === "") {
        echo "Todos los campos son obligatorios";
        exit;
    }

    $stmt = $conexion->prepare(
        "INSERT INTO pacientes (rut, nombre) VALUES (?, ?)"
    );
    $stmt->bind_param("ss", $rut, $nombre);

    if ($stmt->execute()) {
        echo "Paciente creado exitosamente";
    } else {
        echo "Error: el paciente ya existe";
    }
}



