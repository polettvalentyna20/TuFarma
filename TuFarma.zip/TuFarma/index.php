<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>TuFarma – CESFAM Santa Amalia</title>
    <link rel="stylesheet" href="css/estilos.css">
    <style>
        /* Estilos SOLO para el dashboard de inicio */
        .dashboard {
            width: 100%;
            max-width: 900px;
        }

        .dashboard-header {
            text-align: center;
            margin-bottom: 28px;
        }

        .dashboard-header h2 {
            font-size: 26px;
            margin-bottom: 8px;
        }

        .dashboard-header p {
            font-size: 15px;
            color: #555;
            max-width: 720px;
            margin: 0 auto;
            line-height: 1.5;
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
            margin-top: 26px;
        }

        .dashboard-card {
            background: #ffffff;
            border-radius: 18px;
            padding: 26px 22px;
            box-shadow: 0 12px 30px rgba(0,0,0,0.08);
            text-align: left;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .dashboard-card h3 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        .dashboard-card p {
            font-size: 14px;
            color: #555;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .dashboard-card .btn {
            margin-top: auto;
        }

        .icon {
            font-size: 36px;
            margin-bottom: 12px;
        }
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>CESFAM Santa Amalia</p>
</header>

<main class="container">
    <div class="dashboard">

        <!-- TEXTO INSTITUCIONAL -->
        <div class="dashboard-header">
            <h2>Sistema de Gestión Farmacológica</h2>
            <p>
                Plataforma de apoyo para la gestión de pacientes, recetas médicas,
                tratamientos farmacológicos y control de retiros de medicamentos,
                orientada al trabajo clínico del CESFAM Santa Amalia.
            </p>
        </div>

        <!-- TARJETAS DE ACCESO -->
        <div class="dashboard-cards">

            <!-- ADMIN -->
            <div class="dashboard-card">
                <div>
                    <div class="icon">👩‍⚕️</div>
                    <h3>Acceso Administrador</h3>
                    <p>
                        Gestión integral de pacientes, registro de recetas,
                        medicamentos, retiros y control de vigencia.
                        Acceso exclusivo para personal autorizado.
                    </p>
                </div>
                <a class="btn" href="admin/login.php">Ingresar como administrador</a>
            </div>

            <!-- PACIENTE -->
            <div class="dashboard-card">
                <div>
                    <div class="icon">🧑‍🦱</div>
                    <h3>Acceso Paciente</h3>
                    <p>
                        Consulta del estado de sus medicamentos,
                        fechas de retiro, vigencia de receta
                        y seguimiento farmacológico.
                    </p>
                </div>
                <a class="btn btn-outline" href="usuario/login.php">Ingresar como paciente</a>
            </div>

        </div>

    </div>
</main>

</body>
</html>





