<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear cuenta - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .wrap { max-width: 560px; width: 100%; }
        .btn-row{
            display:flex;
            gap:12px;
            justify-content:center;
            flex-wrap:wrap;
            margin-top:14px;
        }
        .btn-row .btn{ width:auto; min-width:220px; }
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Crear cuenta paciente</p>
</header>

<main class="container">
    <div class="card wrap">

        <?php if (!empty($_GET["msg"])): ?>
            <div class="error"><?php echo htmlspecialchars($_GET["msg"]); ?></div>
        <?php endif; ?>

        <form method="POST" action="crear_cuenta_guardar.php" class="block-primary">
            <input type="text" name="rut" placeholder="RUT (debe estar registrado en CESFAM)" required>
            <input type="password" name="clave" placeholder="Nueva contraseña" required>
            <input type="password" name="clave2" placeholder="Repetir contraseña" required>
            <button class="btn">Crear cuenta</button>
        </form>

        <div class="btn-row">
            <a class="btn btn-volver" href="login.php">Volver a login</a>
        </div>

    </div>
</main>

</body>
</html>

