<?php
session_start();
include __DIR__ . "/../data/conexion.php";

$rut   = trim($_POST["rut"] ?? "");
$clave = $_POST["clave"] ?? "";
$clave2= $_POST["clave2"] ?? "";

if ($rut === "" || $clave === "" || $clave2 === "") {
    header("Location: crear_cuenta.php?msg=" . urlencode("Completa todos los campos."));
    exit;
}

if ($clave !== $clave2) {
    header("Location: crear_cuenta.php?msg=" . urlencode("Las contraseñas no coinciden."));
    exit;
}

// Buscar paciente por rut
$stmt = $conn->prepare("SELECT rut, nombre, clave_hash FROM pacientes WHERE rut=? LIMIT 1");
$stmt->bind_param("s", $rut);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();

if (!$p) {
    header("Location: crear_cuenta.php?msg=" . urlencode("RUT no registrado. Solicita al CESFAM que te ingresen."));
    exit;
}

// Si ya tenía cuenta
if (!empty($p["clave_hash"])) {
    header("Location: login.php?msg=" . urlencode("Este RUT ya tiene cuenta. Inicia sesión."));
    exit;
}

$hash = password_hash($clave, PASSWORD_DEFAULT);

// Guardar clave
$stmt = $conn->prepare("UPDATE pacientes SET clave_hash=? WHERE rut=?");
$stmt->bind_param("ss", $hash, $rut);
$stmt->execute();

header("Location: login.php?msg=" . urlencode("Cuenta creada. Ahora puedes ingresar."));
exit;

