<?php
session_start();
if (empty($_SESSION["paciente_rut"])) {
    header("Location: login.php?msg=" . urlencode("Inicia sesión primero."));
    exit;
}

include __DIR__ . "/../data/conexion.php";
date_default_timezone_set("America/Santiago");

$rut = $_SESSION["paciente_rut"];
$nombre = $_SESSION["paciente_nombre"] ?? "Paciente";
$hoy = date("Y-m-d");

function table_exists(mysqli $conn, string $table): bool {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}
function get_columns(mysqli $conn, string $table): array {
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($res) while ($row = $res->fetch_assoc()) $cols[] = $row["Field"];
    return $cols;
}
function pick_col(array $cols, array $candidates): ?string {
    foreach ($candidates as $c) if (in_array($c, $cols, true)) return $c;
    return null;
}
function badge_html(string $text, string $type="neutral"): string {
    $cls = "badge";
    if ($type==="ok") $cls.=" ok";
    if ($type==="warn") $cls.=" warn";
    if ($type==="bad") $cls.=" bad";
    return "<span class=\"$cls\">".htmlspecialchars($text)."</span>";
}

$alertas = [];

/* ===== RECETA ===== */
$receta_estado = "Sin receta";
$receta_type = "bad";
$receta_detalle = "No hay receta registrada. Solicita evaluación en SOME.";
$receta_desde = null;
$receta_hasta = null;

if (table_exists($conn, "recetas")) {
    $colsR = get_columns($conn, "recetas");
    $cRut = pick_col($colsR, ["rut","paciente_rut","rut_paciente"]);
    $cDesde = pick_col($colsR, ["vigente_desde","fecha_inicio","inicio","desde","fecha_desde"]);
    $cHasta = pick_col($colsR, ["vigente_hasta","fecha_termino","termino","hasta","fecha_hasta","fecha_vencimiento"]);

    if ($cRut) {
        $orderCol = in_array("id",$colsR,true) ? "id" : (in_array("creado_en",$colsR,true) ? "creado_en" : $cRut);
        $sql = "SELECT * FROM recetas WHERE `$cRut`=? ORDER BY `$orderCol` DESC LIMIT 1";
        $st = $conn->prepare($sql);
        $st->bind_param("s", $rut);
        $st->execute();
        $rx = $st->get_result()->fetch_assoc();

        if ($rx) {
            $receta_desde = $cDesde ? ($rx[$cDesde] ?? null) : null;
            $receta_hasta = $cHasta ? ($rx[$cHasta] ?? null) : null;

            if ($receta_hasta && $hoy <= $receta_hasta) {
                $receta_estado = "Vigente";
                $receta_type = "ok";
                $receta_detalle = "Receta vigente.";
                $dias = (int)((strtotime($receta_hasta) - strtotime($hoy)) / 86400);
                if ($dias <= 7) {
                    $receta_estado = "Por vencer";
                    $receta_type = "warn";
                    $receta_detalle = "Vence pronto. Renueva con anticipación en SOME.";
                }
            } elseif ($receta_hasta && $hoy > $receta_hasta) {
                $receta_estado = "No vigente";
                $receta_type = "bad";
                $receta_detalle = "Receta vencida. Solicita renovación en SOME.";
            }
        }
    }
}

/* ===== ÚLTIMO RETIRO ===== */
$ult_retiro = null;
$prox_retiro = null;
$ult_retiro_id = null;

if (table_exists($conn, "retiros")) {
    $st = $conn->prepare("
    SELECT id, fecha_retiro, dias_cobertura,
           DATE_ADD(fecha_retiro, INTERVAL dias_cobertura DAY) AS proximo
    FROM retiros
    WHERE rut=?
    ORDER BY fecha_retiro DESC, id DESC
    LIMIT 1
  ");
    $st->bind_param("s", $rut);
    $st->execute();
    $rt = $st->get_result()->fetch_assoc();
    if ($rt) {
        $ult_retiro_id = (int)$rt["id"];
        $ult_retiro = $rt["fecha_retiro"];
        $prox_retiro = $rt["proximo"];
    }
}

/* ===== DETALLE ÚLTIMO RETIRO ===== */
$det = [];
$hasDetalle = table_exists($conn, "retiro_detalle");

if ($hasDetalle && $ult_retiro_id) {
    $sql = "
    SELECT d.estado, d.motivo, m.nombre
    FROM retiro_detalle d
    LEFT JOIN medicamentos m ON m.id = d.medicamento_id
    WHERE d.retiro_id=?
    ORDER BY m.nombre ASC
  ";
    $st = $conn->prepare($sql);
    $st->bind_param("i", $ult_retiro_id);
    $st->execute();
    $res = $st->get_result();
    while($row = $res->fetch_assoc()) $det[] = $row;

    foreach($det as $d){
        if (($d["estado"] ?? "") === "pendiente") {
            $alertas[] = "💡 Tienes medicamentos pendientes (posible sin stock). Revisa en farmacia o SOME.";
            break;
        }
    }
}

if ($receta_type === "bad") $alertas[] = "⚠️ Receta no vigente: solicita renovación en SOME.";
if ($prox_retiro && $hoy > $prox_retiro) $alertas[] = "⏰ Estás atrasada en tu retiro.";

function estado_tag($e){
    if ($e==="entregado") return ["Entregado","ok"];
    if ($e==="parcial") return ["Parcial","warn"];
    return ["Pendiente","bad"];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Paciente - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=paciente-perfect-1">
    <style>
        .row{margin-top:12px}
        .item{padding:12px 0;border-bottom:1px solid #eef2f7}
        .item:last-child{border-bottom:none}
        .muted{color:var(--muted);font-size:13px;margin-top:6px}
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Panel Paciente</p>
</header>

<main class="container">
    <div class="card card-medium">
        <h2 class="card-title">Hola, <?php echo htmlspecialchars($nombre); ?></h2>
        <div class="mini" style="text-align:center;margin-top:4px;">RUT: <?php echo htmlspecialchars($rut); ?></div>

        <?php if (!empty($alertas)): ?>
            <div class="mensaje" style="margin-top:14px;">
                <?php foreach($alertas as $a): ?><div><?php echo htmlspecialchars($a); ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="info-card row">
            <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
                <strong>Estado de receta</strong>
                <?php echo badge_html($receta_estado, $receta_type); ?>
            </div>
            <div class="muted"><?php echo htmlspecialchars($receta_detalle); ?></div>
            <div class="muted">
                <?php if ($receta_desde || $receta_hasta): ?>
                    <?php if ($receta_desde): ?>Vigente desde: <strong><?php echo htmlspecialchars($receta_desde); ?></strong><?php endif; ?>
                    <?php if ($receta_hasta): ?> &nbsp;|&nbsp; Vigente hasta: <strong><?php echo htmlspecialchars($receta_hasta); ?></strong><?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="info-card row">
            <strong>Retiros</strong>
            <div class="muted">
                Último: <strong><?php echo htmlspecialchars($ult_retiro ?? "(sin registro)"); ?></strong><br>
                Próximo: <strong><?php echo htmlspecialchars($prox_retiro ?? "(no calculable)"); ?></strong>
            </div>
        </div>

        <div class="info-card row">
            <strong>Detalle del último retiro</strong>

            <?php if (!$hasDetalle): ?>
                <div class="muted">Aún no está habilitado el detalle por medicamento (retiro_detalle).</div>
            <?php elseif (!$ult_retiro_id): ?>
                <div class="muted">No hay retiros registrados.</div>
            <?php elseif (empty($det)): ?>
                <div class="muted">No hay detalle registrado para el último retiro.</div>
            <?php else: ?>
                <div style="margin-top:10px;">
                    <?php foreach($det as $d): ?>
                        <?php [$lab,$typ] = estado_tag($d["estado"] ?? "pendiente"); ?>
                        <div class="item">
                            <div><strong><?php echo htmlspecialchars($d["nombre"] ?? "Medicamento"); ?></strong></div>
                            <div style="margin-top:6px;"><?php echo badge_html($lab, $typ); ?></div>
                            <?php if (!empty($d["motivo"])): ?>
                                <div class="muted"><?php echo htmlspecialchars($d["motivo"]); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="btn-row" style="margin-top:16px;">
            <a class="btn btn-volver" href="../logout.php">Cerrar sesión</a>
        </div>
    </div>
</main>

</body>
</html>
