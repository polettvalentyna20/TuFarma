<?php
include __DIR__ . "/../data/conexion.php";

$rut = trim($_POST["rut"] ?? "");
$clave1 = trim($_POST["clave1"] ?? "");
$clave2 = trim($_POST["clave2"] ?? "");

if ($rut === "" || $clave1 === "" || $clave2 === "") {
    header("Location: crear_clave.php?error=" . urlencode("Completa todos los campos."));
    exit;
}

if ($clave1 !== $clave2) {
    header("Location: crear_clave.php?error=" . urlencode("Las contraseñas no coinciden."));
    exit;
}

if (strlen($clave1) < 6) {
    header("Location: crear_clave.php?error=" . urlencode("La contraseña debe tener al menos 6 caracteres."));
    exit;
}

// Verificar que el paciente exista (lo crea el admin)
$stmt = $conn->prepare("SELECT rut FROM pacientes WHERE rut=? LIMIT 1");
$stmt->bind_param("s", $rut);
$stmt->execute();
$pac = $stmt->get_result()->fetch_assoc();

if (!$pac) {
    header("Location: crear_clave.php?error=" . urlencode("Ese RUT no está registrado. Solicita al CESFAM que lo ingresen."));
    exit;
}

$hash = password_hash($clave1, PASSWORD_DEFAULT);

// Guardar/actualizar clave
$stmt = $conn->prepare("UPDATE pacientes SET clave_hash=?, activo=1 WHERE rut=?");
$stmt->bind_param("ss", $hash, $rut);

if ($stmt->execute()) {
    header("Location: crear_clave.php?ok=" . urlencode("Contraseña guardada ✅ Ya puedes iniciar sesión."));
    exit;
}

header("Location: crear_clave.php?error=" . urlencode("No se pudo guardar la contraseña."));
exit;

