<?php
session_start();
if (!isset($_SESSION["paciente_rut"])) {
    header("Location: login.php");
    exit;
}
