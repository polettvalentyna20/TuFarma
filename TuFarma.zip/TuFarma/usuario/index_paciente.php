<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";

$rut = $_SESSION["paciente_rut"];
$nombre = $_SESSION["paciente_nombre"] ?? "Paciente";
$hoy = new DateTime("today");

// receta más reciente
$stmt = $conn->prepare("SELECT vigente_desde, vigente_hasta, observacion
                        FROM recetas WHERE rut=? ORDER BY vigente_hasta DESC LIMIT 1");
$stmt->bind_param("s", $rut);
$stmt->execute();
$rec = $stmt->get_result()->fetch_assoc();

$recHasta = $rec ? new DateTime($rec["vigente_hasta"]) : null;
$recOk = $recHasta && $recHasta >= $hoy;

// último retiro
$stmt = $conn->prepare("SELECT fecha_retiro, dias_cobertura, observacion
                        FROM retiros WHERE rut=? ORDER BY fecha_retiro DESC LIMIT 1");
$stmt->bind_param("s", $rut);
$stmt->execute();
$ret = $stmt->get_result()->fetch_assoc();

$ultimo = $ret ? new DateTime($ret["fecha_retiro"]) : null;
$dias = $ret ? (int)$ret["dias_cobertura"] : 30;
$prox = $ultimo ? (clone $ultimo)->modify("+{$dias} days") : null;

$corresponde = $prox && $prox <= $hoy;
$alDia = $prox && $prox > $hoy;

// medicamentos activos
$stmt = $conn->prepare("
  SELECT m.nombre, m.presentacion, t.dosis, t.indicacion
  FROM tratamientos t
  JOIN medicamentos m ON m.id = t.medicamento_id
  WHERE t.rut=? AND t.activo=1
  ORDER BY m.nombre ASC
");
$stmt->bind_param("s", $rut);
$stmt->execute();
$meds = $stmt->get_result();

// historial últimos 6 retiros
$stmt = $conn->prepare("SELECT fecha_retiro, dias_cobertura, observacion
                        FROM retiros WHERE rut=? ORDER BY fecha_retiro DESC LIMIT 6");
$stmt->bind_param("s", $rut);
$stmt->execute();
$hist = $stmt->get_result();

function badge($tipo, $texto) {
    $map = [
            "ok" => "background: rgba(67,160,71,.12); color:#2e7d32;",
            "warn" => "background: rgba(255,193,7,.18); color:#8a6d00;",
            "danger" => "background: rgba(229,57,53,.12); color:#b71c1c;",
            "info" => "background: rgba(30,136,229,.12); color:#1565c0;",
    ];
    $style = $map[$tipo] ?? $map["info"];
    return "<span style='display:inline-block;padding:6px 10px;border-radius:999px;font-weight:bold;font-size:12px;$style'>$texto</span>";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi tratamiento - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        .wrap { max-width: 900px; width:100%; }
        .mini { color:#555; font-size: 14px; }
        .section { text-align:left; margin-top: 16px; }
        .item { padding: 10px 0; border-bottom: 1px solid #eee; }
        .alerta { padding: 12px 14px; border-radius: 12px; margin-top: 14px; }
        .alerta.danger { background: rgba(229,57,53,.10); border:1px solid rgba(229,57,53,.25); }
        .alerta.warn { background: rgba(255,193,7,.16); border:1px solid rgba(255,193,7,.25); }
        .alerta.ok { background: rgba(67,160,71,.10); border:1px solid rgba(67,160,71,.20); }
        .grid { display:grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px; }
        .box { background:#fff; border:1px solid #eee; border-radius: 12px; padding: 12px; }
        @media (max-width: 700px){ .grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p><?php echo htmlspecialchars($nombre); ?> — <?php echo htmlspecialchars($rut); ?></p>
</header>

<main class="container">
    <div class="card wrap">
        <h2 class="card-title">Mi estado de medicamentos</h2>

        <!-- ALERTAS PRINCIPALES -->
        <?php if (!$recHasta): ?>
            <div class="alerta danger">
                <div><strong>⚠️ No tienes receta registrada</strong> <?php echo badge("danger","Solicitar en SOME"); ?></div>
                <div class="mini">Para programar despacho/continuidad, debes solicitar receta vigente.</div>
            </div>
        <?php elseif (!$recOk): ?>
            <div class="alerta danger">
                <div><strong>⚠️ Receta NO vigente</strong> <?php echo badge("danger","Solicitar en SOME"); ?></div>
                <div class="mini">Venció el <?php echo $recHasta->format("d-m-Y"); ?>.</div>
            </div>
        <?php elseif (!$ultimo): ?>
            <div class="alerta warn">
                <div><strong>🟡 Aún no hay retiros registrados</strong> <?php echo badge("warn","Pendiente"); ?></div>
                <div class="mini">Acércate a farmacia para registrar tu primer retiro.</div>
            </div>
        <?php elseif ($corresponde): ?>
            <div class="alerta warn">
                <div><strong>🟡 Te corresponde retiro</strong> <?php echo badge("warn","Corresponde"); ?></div>
                <div class="mini">Tu retiro correspondía desde el <?php echo $prox->format("d-m-Y"); ?>.</div>
            </div>
        <?php else: ?>
            <div class="alerta ok">
                <div><strong>✅ Estás al día</strong> <?php echo badge("ok","Al día"); ?></div>
                <div class="mini">Tu próximo retiro será el <?php echo $prox ? $prox->format("d-m-Y") : "—"; ?>.</div>
            </div>
        <?php endif; ?>

        <!-- RESUMEN EN CAJAS -->
        <div class="grid">
            <div class="box">
                <div><strong>Receta</strong></div>
                <?php if (!$recHasta): ?>
                    <div><?php echo badge("danger","Sin receta"); ?></div>
                    <div class="mini">Solicitar en SOME</div>
                <?php elseif ($recOk): ?>
                    <div><?php echo badge("ok","Vigente"); ?></div>
                    <div class="mini">Hasta: <?php echo $recHasta->format("d-m-Y"); ?></div>
                <?php else: ?>
                    <div><?php echo badge("danger","No vigente"); ?></div>
                    <div class="mini">Venció: <?php echo $recHasta->format("d-m-Y"); ?></div>
                <?php endif; ?>
            </div>

            <div class="box">
                <div><strong>Retiros</strong></div>
                <div class="mini"><strong>Último:</strong> <?php echo $ultimo ? $ultimo->format("d-m-Y") : "—"; ?></div>
                <div class="mini"><strong>Próximo:</strong> <?php echo $prox ? $prox->format("d-m-Y") : "—"; ?></div>
                <div class="mini"><strong>Cobertura:</strong> <?php echo $ultimo ? $dias . " días" : "—"; ?></div>
            </div>
        </div>

        <!-- MEDICAMENTOS -->
        <div class="section">
            <h3>Medicamentos indicados</h3>
            <?php if ($meds->num_rows === 0): ?>
                <div class="mini">No hay medicamentos activos registrados.</div>
            <?php else: ?>
                <?php while($m = $meds->fetch_assoc()): ?>
                    <div class="item">
                        <div>
                            <strong><?php echo htmlspecialchars($m["nombre"]); ?></strong>
                            <?php if (!empty($m["presentacion"])): ?>
                                <span class="mini">(<?php echo htmlspecialchars($m["presentacion"]); ?>)</span>
                            <?php endif; ?>
                        </div>
                        <div class="mini"><strong>Dosis / gramaje:</strong> <?php echo htmlspecialchars($m["dosis"]); ?></div>
                        <div class="mini"><strong>Indicaciones:</strong> <?php echo htmlspecialchars($m["indicacion"]); ?></div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

        <!-- HISTORIAL -->
        <div class="section">
            <h3>Historial de retiros (últimos 6)</h3>
            <?php if ($hist->num_rows === 0): ?>
                <div class="mini">Sin retiros registrados.</div>
            <?php else: ?>
                <?php while($h = $hist->fetch_assoc()): ?>
                    <div class="item">
                        <div><strong><?php echo (new DateTime($h["fecha_retiro"]))->format("d-m-Y"); ?></strong></div>
                        <div class="mini">Cobertura: <?php echo (int)$h["dias_cobertura"]; ?> días</div>
                        <?php if (!empty($h["observacion"])): ?>
                            <div class="mini"><?php echo htmlspecialchars($h["observacion"]); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

        <div style="margin-top:16px;">
            <a class="btn" href="../logout.php" style="background:#e53935;">Cerrar sesión</a>
        </div>
    </div>
</main>

</body>
</html>

