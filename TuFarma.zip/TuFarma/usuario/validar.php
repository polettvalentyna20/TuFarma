<?php
session_start();
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/../data/rut.php";

$rut_in = trim($_POST["rut"] ?? "");
$clave  = $_POST["clave"] ?? "";

if ($rut_in === "" || $clave === "") {
    header("Location: login.php?msg=" . urlencode("Completa RUT y contraseña."));
    exit;
}
if (!rut_is_valid($rut_in)) {
    header("Location: login.php?msg=" . urlencode("RUT inválido (DV incorrecto)."));
    exit;
}

$rut_norm = rut_normalize($rut_in);
$rut_comp = rut_compact($rut_norm); // ✅ num+dv (ej 123456789)

// Detectar si existe columna 'activo'
$cols = [];
$res = $conn->query("SHOW COLUMNS FROM pacientes");
if ($res) while ($row = $res->fetch_assoc()) $cols[] = $row["Field"];
$hasActivo = in_array("activo", $cols, true);

$sql = "SELECT rut, nombre, clave_hash" . ($hasActivo ? ", activo" : "") . "
        FROM pacientes
        WHERE REPLACE(REPLACE(rut,'.',''),'-','') = ?
        LIMIT 1";

$st = $conn->prepare($sql);
$st->bind_param("s", $rut_comp);
$st->execute();
$p = $st->get_result()->fetch_assoc();

if (!$p) {
    header("Location: login.php?msg=" . urlencode("RUT no registrado."));
    exit;
}

if ($hasActivo && isset($p["activo"]) && (int)$p["activo"] !== 1) {
    header("Location: login.php?msg=" . urlencode("Cuenta desactivada. Consulta en el CESFAM."));
    exit;
}

if (empty($p["clave_hash"])) {
    header("Location: login.php?msg=" . urlencode("Aún no tienes cuenta. Crea tu cuenta primero."));
    exit;
}

if (!password_verify($clave, $p["clave_hash"])) {
    header("Location: login.php?msg=" . urlencode("Contraseña incorrecta."));
    exit;
}

$_SESSION["paciente_rut"] = $rut_norm;             // guardamos estándar 12345678-9
$_SESSION["paciente_nombre"] = $p["nombre"] ?? "Paciente";

header("Location: panel.php");
exit;

