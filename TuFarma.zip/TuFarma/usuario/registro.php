<?php
session_start();
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/../data/rut.php";

$msg = trim($_GET["msg"] ?? "");
$err = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $rut_in = trim($_POST["rut"] ?? "");
    $nombre = trim($_POST["nombre"] ?? "");
    $clave1 = $_POST["clave1"] ?? "";
    $clave2 = $_POST["clave2"] ?? "";

    if ($rut_in==="" || $nombre==="" || $clave1==="" || $clave2==="") {
        $err = "Completa todos los campos.";
    } elseif (!rut_is_valid($rut_in)) {
        $err = "RUT inválido (DV incorrecto).";
    } elseif ($clave1 !== $clave2) {
        $err = "Las contraseñas no coinciden.";
    } elseif (strlen($clave1) < 4) {
        $err = "La contraseña debe tener al menos 4 caracteres.";
    } else {
        $rut_norm = rut_normalize($rut_in);
        $rut_comp = rut_compact($rut_norm); // ✅ num+dv

        // Verificar que exista en pacientes (aunque esté con puntos)
        $sql = "SELECT rut, nombre, clave_hash
            FROM pacientes
            WHERE REPLACE(REPLACE(rut,'.',''),'-','') = ?
            LIMIT 1";
        $st = $conn->prepare($sql);
        $st->bind_param("s", $rut_comp);
        $st->execute();
        $p = $st->get_result()->fetch_assoc();

        if (!$p) {
            $err = "RUT no registrado. Solicita al CESFAM que te ingresen.";
        } else {
            if (!empty($p["clave_hash"])) {
                $err = "Este paciente ya tiene cuenta creada. Usa 'Ingresar'.";
            } else {
                $hash = password_hash($clave1, PASSWORD_DEFAULT);

                // Normalizamos rut/nombre y guardamos clave
                $st2 = $conn->prepare("UPDATE pacientes SET rut=?, nombre=?, clave_hash=? WHERE REPLACE(REPLACE(rut,'.',''),'-','')=?");
                $st2->bind_param("ssss", $rut_norm, $nombre, $hash, $rut_comp);
                $st2->execute();

                header("Location: login.php?msg=" . urlencode("Cuenta creada. Ahora puedes ingresar."));
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear cuenta paciente - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=registro-rut-fix-2">
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Crear cuenta paciente</p>
</header>

<main class="container">
    <div class="card card-compact">
        <h2 class="card-title">Crear cuenta</h2>

        <?php if ($msg): ?><div class="mensaje"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
        <?php if ($err): ?><div class="error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

        <form method="POST" class="block-primary">
            <input type="text" name="rut" placeholder="RUT (ej: 12.345.678-9)" required>
            <input type="text" name="nombre" placeholder="Nombre completo" required>
            <input type="password" name="clave1" placeholder="Contraseña" required>
            <input type="password" name="clave2" placeholder="Repite contraseña" required>
            <button class="btn" type="submit">Crear cuenta</button>
        </form>

        <div class="btn-row">
            <a class="btn btn-volver" href="login.php">Volver a ingresar</a>
        </div>
    </div>
</main>

</body>
</html>
