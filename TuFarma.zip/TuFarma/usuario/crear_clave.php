<?php
session_start();
$err = $_GET["error"] ?? "";
$ok  = $_GET["ok"] ?? "";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear / Recuperar contraseña - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Crear / Recuperar contraseña</p>
</header>

<main class="container">
    <div class="card">
        <h2 class="card-title">Actualizar contraseña</h2>

        <?php if ($err): ?><div class="error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
        <?php if ($ok): ?><div class="mensaje"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>

        <!-- BLOQUE PRINCIPAL -->
        <div class="block-primary">
            <form method="POST" action="guardar_clave.php">
                <input type="text" name="rut" placeholder="RUT (ej: 12.345.678-9)" required>
                <input type="password" name="clave1" placeholder="Nueva contraseña (mínimo 6)" required>
                <input type="password" name="clave2" placeholder="Repite la nueva contraseña" required>
                <button class="btn" type="submit">Guardar contraseña</button>
            </form>
        </div>

        <!-- BLOQUE VOLVER (separado, nunca pegado) -->
        <div class="block-tertiary">
            <a class="btn btn-volver" href="login.php">Volver al login</a>
            <div style="height:12px;"></div>
            <a class="btn btn-outline" href="../index.php">Volver al inicio</a>
        </div>

    </div>
</main>

</body>
</html>

