<?php
include("../data/conexion.php");

$rut = $_POST['rut'];
$nombre = $_POST['nombre'];
$medicamento = $_POST['medicamento'];

$conn->query("INSERT INTO pacientes (rut, nombre)
              VALUES ('$rut', '$nombre')");

$paciente_id = $conn->insert_id;

$conn->query("INSERT INTO medicamentos (paciente_id, nombre_medicamento)
              VALUES ($paciente_id, '$medicamento')");

echo "Registro guardado correctamente";
?>
