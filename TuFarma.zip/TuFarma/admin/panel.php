<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";

$adminNombre = $_SESSION["admin_nombre"] ?? "Administrador";
$adminEst = $_SESSION["admin_establecimiento"] ?? "CESFAM";

$q = trim($_GET["q"] ?? "");

$items = [];
if ($q !== "") {
    $like = "%".$q."%";
    $st = $conn->prepare("SELECT rut, nombre FROM pacientes WHERE rut LIKE ? OR nombre LIKE ? ORDER BY nombre ASC LIMIT 80");
    $st->bind_param("ss", $like, $like);
    $st->execute();
    $items = $st->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $res = $conn->query("SELECT rut, nombre FROM pacientes ORDER BY nombre ASC LIMIT 80");
    if ($res) $items = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=panel-admin-fix-1">
    <style>
        .wrap{max-width:980px;width:100%}
        table{width:100%;border-collapse:collapse}
        th,td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left;vertical-align:top}
        thead tr{background:#f5f7fa}
        .topbar{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center}
        .search{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:12px}
        .search input{max-width:380px;margin:0}
        .search .btn{width:auto;margin:0;min-width:140px}
        .actions-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px}
        @media(max-width:720px){.actions-grid{grid-template-columns:1fr}}
        .actions-grid .btn{margin-top:0}
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Panel Administrador</p>
</header>

<main class="container">
    <div class="card wrap">
        <div class="topbar">
            <div>
                <h2 class="card-title" style="text-align:left;margin:0;">Hola, <?php echo htmlspecialchars($adminNombre); ?></h2>
                <div class="mini"><?php echo htmlspecialchars($adminEst); ?></div>
            </div>
            <a class="btn btn-volver" style="width:auto;min-width:180px;" href="../logout.php">Cerrar sesión</a>
        </div>

        <div class="actions-grid">
            <a class="btn" href="paciente_nuevo.php">➕ Agregar paciente</a>
            <a class="btn" href="admin_nuevo.php">➕ Agregar administrador</a>
            <a class="btn" href="stock_critico.php">📦 Stock crítico</a>
            <a class="btn" href="stock_masivo.php">🏥 Ingreso masivo de stock</a>
            <a class="btn" href="auditoria.php">🧾 Auditoría</a>
            <a class="btn btn-secondary" href="panel.php">🔄 Refrescar</a>
        </div>

        <form class="search" method="GET" action="panel.php">
            <input type="text" name="q" placeholder="Buscar paciente por RUT o nombre..." value="<?php echo htmlspecialchars($q); ?>">
            <button class="btn" type="submit">Buscar</button>
            <?php if ($q !== ""): ?>
                <a class="btn btn-volver" style="width:auto;min-width:140px;" href="panel.php">Limpiar</a>
            <?php endif; ?>
        </form>

        <div class="section" style="margin-top:14px;">
            <h3 style="margin:10px 0 8px;">Pacientes</h3>

            <?php if (empty($items)): ?>
                <div class="mensaje">No se encontraron pacientes.</div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>RUT</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($items as $p): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($p["nombre"]); ?></strong></td>
                                <td><?php echo htmlspecialchars($p["rut"]); ?></td>
                                <td>
                                    <a class="btn" style="width:auto;min-width:240px;margin:0;"
                                       href="ver_paciente.php?rut=<?php echo urlencode($p["rut"]); ?>">
                                        💊 Gestión retiro de medicamentos
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

</body>
</html>
