<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
date_default_timezone_set("America/Santiago");

$rut = trim($_GET["rut"] ?? "");
if ($rut === "") { header("Location: panel.php"); exit; }

$adminId = $_SESSION["admin_id"] ?? null;

function table_exists(mysqli $conn, string $table): bool {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}
function get_columns(mysqli $conn, string $table): array {
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($res) while ($row = $res->fetch_assoc()) $cols[] = $row["Field"];
    return $cols;
}
function has_col(array $cols, string $col): bool { return in_array($col, $cols, true); }
function badge($txt, $type="neutral"){
    $cls="badge";
    if($type==="ok") $cls.=" ok";
    if($type==="warn") $cls.=" warn";
    if($type==="bad") $cls.=" bad";
    return "<span class=\"$cls\">".htmlspecialchars($txt)."</span>";
}

$err = "";
$ok  = "";

/* ======================
   Paciente
====================== */
$stmt = $conn->prepare("SELECT rut, nombre FROM pacientes WHERE rut=? LIMIT 1");
$stmt->bind_param("s", $rut);
$stmt->execute();
$pac = $stmt->get_result()->fetch_assoc();
if (!$pac) die("Paciente no encontrado");

/* ======================
   Tablas y columnas
====================== */
$colsRec = table_exists($conn, "recetas") ? get_columns($conn, "recetas") : [];
$colsRet = table_exists($conn, "retiros") ? get_columns($conn, "retiros") : [];
$colsMed = table_exists($conn, "medicamentos") ? get_columns($conn, "medicamentos") : [];
$colsTr  = table_exists($conn, "tratamientos") ? get_columns($conn, "tratamientos") : [];
$hasDetalle = table_exists($conn, "retiro_detalle");

/* ======================
   Acciones POST
====================== */

/* Guardar receta */
if (isset($_POST["guardar_receta"])) {
    $desde = $_POST["vigente_desde"] ?? "";
    $hasta = $_POST["vigente_hasta"] ?? "";
    $obs   = trim($_POST["observacion"] ?? "");

    if ($desde === "" || $hasta === "") {
        $err = "Completa Vigente desde y Vigente hasta.";
    } else {
        $st = $conn->prepare("INSERT INTO recetas (rut, vigente_desde, vigente_hasta, observacion) VALUES (?, ?, ?, ?)");
        $st->bind_param("ssss", $rut, $desde, $hasta, $obs);
        $st->execute();
        header("Location: ver_paciente.php?rut=" . urlencode($rut));
        exit;
    }
}

/* Guardar medicamento */
if (isset($_POST["guardar_medicamento"])) {
    $nombre = trim($_POST["med_nombre"] ?? "");
    $dosis = trim($_POST["dosis"] ?? "");
    $indicacion = trim($_POST["indicacion"] ?? "");

    if ($nombre==="" || $dosis==="" || $indicacion==="") {
        $err = "Completa nombre, dosis e indicación.";
    } else {
        if (!table_exists($conn, "medicamentos") || !table_exists($conn, "tratamientos")) {
            $err = "Faltan tablas medicamentos/tratamientos.";
        } else {
            if (has_col($colsMed, "stock_actual") && has_col($colsMed, "stock_minimo")) {
                $st = $conn->prepare("INSERT INTO medicamentos (nombre, stock_actual, stock_minimo) VALUES (?, 0, 5)");
                $st->bind_param("s", $nombre);
            } else {
                $st = $conn->prepare("INSERT INTO medicamentos (nombre) VALUES (?)");
                $st->bind_param("s", $nombre);
            }
            $st->execute();
            $med_id = $conn->insert_id;

            $st2 = $conn->prepare("INSERT INTO tratamientos (rut, medicamento_id, dosis, indicacion) VALUES (?, ?, ?, ?)");
            $st2->bind_param("siss", $rut, $med_id, $dosis, $indicacion);
            $st2->execute();

            header("Location: ver_paciente.php?rut=" . urlencode($rut));
            exit;
        }
    }
}

/* Actualizar stock */
if (isset($_POST["actualizar_stock"])) {
    $med_id = (int)($_POST["med_id"] ?? 0);
    $stock_actual = (int)($_POST["stock_actual"] ?? 0);
    $stock_minimo = (int)($_POST["stock_minimo"] ?? 5);

    if ($med_id <= 0) $err = "Medicamento inválido.";
    else {
        if (has_col($colsMed, "stock_actual") && has_col($colsMed, "stock_minimo")) {
            $st = $conn->prepare("UPDATE medicamentos SET stock_actual=?, stock_minimo=? WHERE id=?");
            $st->bind_param("iii", $stock_actual, $stock_minimo, $med_id);
            $st->execute();
        }
        header("Location: ver_paciente.php?rut=" . urlencode($rut));
        exit;
    }
}

/* Registrar retiro + detalle con autocorrección por stock */
if (isset($_POST["guardar_retiro"])) {
    $fecha = $_POST["fecha_retiro"] ?? "";
    $dias  = (int)($_POST["dias_cobertura"] ?? 0);
    $obsRet = trim($_POST["obs_retiro"] ?? "");

    if ($fecha==="" || $dias<=0) {
        $err = "Completa fecha y días de cobertura.";
    } else {
        $conn->begin_transaction();
        try {
            // Insert retiro (según columnas)
            $hasAdminId = has_col($colsRet, "admin_id");
            $hasObs     = has_col($colsRet, "observacion");
            $hasCreado  = has_col($colsRet, "creado_en");

            if ($hasAdminId && $hasObs && $hasCreado) {
                $st = $conn->prepare("INSERT INTO retiros (rut, fecha_retiro, dias_cobertura, observacion, admin_id, creado_en) VALUES (?, ?, ?, ?, ?, NOW())");
                $aid = $adminId ? (int)$adminId : null;
                $st->bind_param("ssisi", $rut, $fecha, $dias, $obsRet, $aid);
            } elseif ($hasAdminId && $hasObs) {
                $st = $conn->prepare("INSERT INTO retiros (rut, fecha_retiro, dias_cobertura, observacion, admin_id) VALUES (?, ?, ?, ?, ?)");
                $aid = $adminId ? (int)$adminId : null;
                $st->bind_param("ssisi", $rut, $fecha, $dias, $obsRet, $aid);
            } elseif ($hasObs) {
                $st = $conn->prepare("INSERT INTO retiros (rut, fecha_retiro, dias_cobertura, observacion) VALUES (?, ?, ?, ?)");
                $st->bind_param("ssis", $rut, $fecha, $dias, $obsRet);
            } else {
                $st = $conn->prepare("INSERT INTO retiros (rut, fecha_retiro, dias_cobertura) VALUES (?, ?, ?)");
                $st->bind_param("ssi", $rut, $fecha, $dias);
            }
            $st->execute();
            $retiro_id = $conn->insert_id;

            // Detalle por medicamento (si existe tabla)
            if ($hasDetalle && table_exists($conn, "medicamentos")) {
                $det = $_POST["det"] ?? [];

                // Pre-cargar stock por id para autocorrección
                $stockMap = [];
                if (has_col($colsMed, "stock_actual")) {
                    $res = $conn->query("SELECT id, stock_actual FROM medicamentos");
                    if ($res) while($r = $res->fetch_assoc()) $stockMap[(int)$r["id"]] = (int)$r["stock_actual"];
                }

                if (is_array($det)) {
                    foreach ($det as $medIdStr => $info) {
                        $medId = (int)$medIdStr;
                        if ($medId <= 0) continue;

                        $estado = $info["estado"] ?? "pendiente";
                        $motivo = trim($info["motivo"] ?? "");
                        if (!in_array($estado, ["entregado","parcial","pendiente"], true)) $estado = "pendiente";

                        // ✅ AUTOCORRECCIÓN POR STOCK
                        $stockActual = $stockMap[$medId] ?? null; // null si no hay stock en tabla
                        if ($stockActual !== null && $stockActual <= 0 && ($estado === "entregado" || $estado === "parcial")) {
                            $estado = "pendiente";
                            if ($motivo === "") $motivo = "Sin stock";
                        }

                        // Si queda pendiente y no hay motivo, sugerimos uno suave
                        if ($estado === "pendiente" && $motivo === "") {
                            $motivo = "Pendiente por entrega";
                        }

                        $stD = $conn->prepare("INSERT INTO retiro_detalle (retiro_id, rut, medicamento_id, estado, motivo) VALUES (?, ?, ?, ?, ?)");
                        $stD->bind_param("isiss", $retiro_id, $rut, $medId, $estado, $motivo);
                        $stD->execute();

                        // ✅ Descontar stock SOLO si entregado/parcial y hay stock
                        if ($stockActual !== null && ($estado === "entregado" || $estado === "parcial") && $stockActual > 0) {
                            $conn->query("UPDATE medicamentos SET stock_actual = GREATEST(stock_actual - 1, 0) WHERE id=".(int)$medId);
                            $stockMap[$medId] = max($stockActual - 1, 0);
                        }
                    }
                }
            }

            $conn->commit();
            header("Location: ver_paciente.php?rut=" . urlencode($rut));
            exit;

        } catch (Throwable $e) {
            $conn->rollback();
            $err = "Error al registrar retiro: " . $e->getMessage();
        }
    }
}

/* ======================
   CONSULTAS PARA VISTA
====================== */

/* Última receta + historial recetas */
$rec = null;
$histRecetas = [];
if (table_exists($conn, "recetas")) {
    $st = $conn->prepare("SELECT vigente_desde, vigente_hasta, observacion, creado_en FROM recetas WHERE rut=? ORDER BY creado_en DESC LIMIT 1");
    $st->bind_param("s", $rut);
    $st->execute();
    $rec = $st->get_result()->fetch_assoc();

    $st = $conn->prepare("SELECT vigente_desde, vigente_hasta, observacion, creado_en FROM recetas WHERE rut=? ORDER BY creado_en DESC LIMIT 10");
    $st->bind_param("s", $rut);
    $st->execute();
    $histRecetas = $st->get_result()->fetch_all(MYSQLI_ASSOC);
}

/* Conteo retiros + último */
$st = $conn->prepare("SELECT COUNT(*) AS c FROM retiros WHERE rut=?");
$st->bind_param("s", $rut);
$st->execute();
$cntRetiros = (int)($st->get_result()->fetch_assoc()["c"] ?? 0);

$ultRet = null;
$st = $conn->prepare("
  SELECT id, fecha_retiro, dias_cobertura,
         DATE_ADD(fecha_retiro, INTERVAL dias_cobertura DAY) AS proximo
  FROM retiros
  WHERE rut=?
  ORDER BY fecha_retiro DESC, id DESC
  LIMIT 1
");
$st->bind_param("s", $rut);
$st->execute();
$ultRet = $st->get_result()->fetch_assoc();

/* Medicamentos (actuales) */
$meds = [];
if (table_exists($conn, "tratamientos") && table_exists($conn, "medicamentos")) {
    if (has_col($colsMed, "stock_actual") && has_col($colsMed, "stock_minimo")) {
        $st = $conn->prepare("
      SELECT m.id, m.nombre, m.stock_actual, m.stock_minimo, t.dosis, t.indicacion
      FROM tratamientos t
      JOIN medicamentos m ON m.id = t.medicamento_id
      WHERE t.rut=?
      ORDER BY m.nombre ASC
    ");
    } else {
        $st = $conn->prepare("
      SELECT m.id, m.nombre, 0 AS stock_actual, 0 AS stock_minimo, t.dosis, t.indicacion
      FROM tratamientos t
      JOIN medicamentos m ON m.id = t.medicamento_id
      WHERE t.rut=?
      ORDER BY m.nombre ASC
    ");
    }
    $st->bind_param("s", $rut);
    $st->execute();
    $res = $st->get_result();
    while($row=$res->fetch_assoc()) $meds[]=$row;
}

/* Historial retiros + detalles */
$hist = [];
$st = $conn->prepare("
  SELECT r.id, r.fecha_retiro, r.dias_cobertura, r.observacion, r.creado_en,
         a.nombre AS admin_nombre, a.establecimiento AS admin_est
  FROM retiros r
  LEFT JOIN admins a ON a.id = r.admin_id
  WHERE r.rut=?
  ORDER BY r.fecha_retiro DESC, r.id DESC
  LIMIT 20
");
$st->bind_param("s", $rut);
$st->execute();
$hist = $st->get_result()->fetch_all(MYSQLI_ASSOC);

$histDet = [];
if ($hasDetalle && !empty($hist)) {
    $ids = array_map(fn($x)=> (int)$x["id"], $hist);
    $in = implode(",", $ids);
    $sql = "
    SELECT d.retiro_id, d.medicamento_id, d.estado, d.motivo, m.nombre
    FROM retiro_detalle d
    LEFT JOIN medicamentos m ON m.id = d.medicamento_id
    WHERE d.retiro_id IN ($in)
    ORDER BY d.retiro_id DESC, m.nombre ASC
  ";
    $res = $conn->query($sql);
    if ($res) {
        while($r = $res->fetch_assoc()){
            $rid = (int)$r["retiro_id"];
            if (!isset($histDet[$rid])) $histDet[$rid] = [];
            $histDet[$rid][] = $r;
        }
    }
}

/* Estado receta semáforo */
$hoy = date("Y-m-d");
$estadoReceta = "Sin receta";
$tipoBadge = "bad";
$detalle = "Debe solicitar receta en SOME.";

if ($rec) {
    if ($cntRetiros >= 1) {
        $estadoReceta = "Despachada";
        $tipoBadge = "ok";
        $detalle = "Existe al menos un despacho registrado.";
    } else if ($hoy >= $rec["vigente_desde"] && $hoy <= $rec["vigente_hasta"]) {
        $estadoReceta = "Vigente";
        $tipoBadge = "ok";
        $detalle = "Vigente desde {$rec["vigente_desde"]} hasta {$rec["vigente_hasta"]}.";
        $dias = (int)((strtotime($rec["vigente_hasta"]) - strtotime($hoy)) / 86400);
        if ($dias <= 7) {
            $estadoReceta = "Por vencer";
            $tipoBadge = "warn";
            $detalle = "Vence pronto ({$rec["vigente_hasta"]}). Renovar en SOME.";
        }
    } else {
        $estadoReceta = "No vigente";
        $tipoBadge = "bad";
        $detalle = "Venció: {$rec["vigente_hasta"]}. Solicitar nueva receta en SOME.";
    }
}

function stock_tag($actual, $min){
    $actual=(int)$actual; $min=(int)$min;
    if($actual<=0) return ["Sin stock","bad"];
    if($actual<=$min) return ["Crítico","warn"];
    return ["OK","ok"];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Retiro - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=verpaciente-perfect-1">
    <style>
        .wrap{max-width:980px;width:100%}
        .sec{margin-top:18px;text-align:left}
        .grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        @media(max-width:900px){.grid{grid-template-columns:1fr}}
        .box{border:1px solid var(--border);border-radius:16px;padding:16px;background:#fff}
        .muted{color:var(--muted);font-size:13px}
        .medline{padding:12px 0;border-bottom:1px solid #eef2f7}
        .medline:last-child{border-bottom:none}
        .det-grid{display:grid;grid-template-columns:1fr 180px 1fr;gap:10px;align-items:center}
        @media(max-width:900px){.det-grid{grid-template-columns:1fr}}
        .det-grid select,.det-grid input{margin:0}
        .table-scroll{overflow-x:auto}
        table{width:100%;border-collapse:collapse;min-width:920px}
        th,td{padding:10px;border-bottom:1px solid #eef2f7;vertical-align:top;text-align:left}
        thead tr{background:#f5f7fa}
        .pill{display:inline-block;padding:6px 10px;border-radius:999px;background:#eef2f7;font-weight:800;font-size:12px}
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Gestión de Retiro de Medicamentos</p>
</header>

<main class="container">
    <div class="card wrap">

        <h2 class="card-title"><?php echo htmlspecialchars($pac["nombre"]); ?></h2>
        <div class="mini"><?php echo htmlspecialchars($pac["rut"]); ?></div>

        <?php if ($err): ?>
            <div class="error" style="margin-top:14px;"><?php echo htmlspecialchars($err); ?></div>
        <?php endif; ?>

        <div class="sec">
            <h3>Estado de receta</h3>
            <div style="margin-top:8px;">
                <?php echo badge($estadoReceta, $tipoBadge); ?>
            </div>
            <div class="muted" style="margin-top:6px;"><?php echo htmlspecialchars($detalle); ?></div>
            <?php if ($rec && !empty($rec["observacion"])): ?>
                <div class="muted" style="margin-top:6px;"><strong>Obs:</strong> <?php echo htmlspecialchars($rec["observacion"]); ?></div>
            <?php endif; ?>
        </div>

        <div class="sec grid">
            <div class="box">
                <h3>Registrar receta</h3>
                <form method="POST" class="block-primary" style="margin:0;">
                    <input type="date" name="vigente_desde" required>
                    <input type="date" name="vigente_hasta" required>
                    <input type="text" name="observacion" placeholder="Observación (opcional)">
                    <button class="btn" name="guardar_receta">Guardar receta</button>
                </form>

                <div style="margin-top:14px;">
                    <h4 style="margin:0 0 6px 0;">Historial recetas (últimas 10)</h4>
                    <?php if (empty($histRecetas)): ?>
                        <div class="mini">Sin recetas anteriores.</div>
                    <?php else: ?>
                        <div class="list">
                            <?php foreach($histRecetas as $hr): ?>
                                <div class="item">
                                    <div class="top">
                                        <div><strong><?php echo htmlspecialchars($hr["vigente_desde"]); ?></strong> → <strong><?php echo htmlspecialchars($hr["vigente_hasta"]); ?></strong></div>
                                        <div class="mini"><?php echo htmlspecialchars($hr["creado_en"] ?? ""); ?></div>
                                    </div>
                                    <?php if (!empty($hr["observacion"])): ?>
                                        <div class="muted"><?php echo htmlspecialchars($hr["observacion"]); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="box">
                <h3>Registrar retiro (detalle + autocorrección por stock)</h3>

                <?php if (!$hasDetalle): ?>
                    <div class="mensaje" style="margin-top:10px;">
                        Falta la tabla <strong>retiro_detalle</strong>. Ejecuta el SQL para habilitar entrega parcial/pendiente.
                    </div>
                <?php endif; ?>

                <?php if ($ultRet): ?>
                    <div class="muted" style="margin-top:10px;">
                        Último retiro: <strong><?php echo htmlspecialchars($ultRet["fecha_retiro"]); ?></strong><br>
                        Próximo retiro estimado: <strong><?php echo htmlspecialchars($ultRet["proximo"]); ?></strong>
                    </div>
                    <hr style="margin:12px 0;">
                <?php endif; ?>

                <form method="POST" class="block-primary" style="margin:0;">
                    <input type="date" name="fecha_retiro" required>
                    <input type="number" name="dias_cobertura" placeholder="Días cobertura (ej: 30)" required>
                    <input type="text" name="obs_retiro" placeholder="Observación general (opcional)">

                    <?php if (!empty($meds)): ?>
                        <div class="box" style="padding:14px;background:#f9fafb;border:1px solid #eef2f7;">
                            <strong>Detalle por medicamento</strong>
                            <div class="muted" style="margin-top:6px;">
                                Si marcas Entregado/Parcial y no hay stock, se autocorrige a Pendiente + “Sin stock”.
                            </div>

                            <div style="margin-top:10px;">
                                <?php foreach($meds as $m): ?>
                                    <?php [$stxt,$scls] = stock_tag($m["stock_actual"], $m["stock_minimo"]); ?>
                                    <div class="medline">
                                        <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
                                            <div>
                                                <strong><?php echo htmlspecialchars($m["nombre"]); ?></strong>
                                                <div class="muted"><?php echo htmlspecialchars($m["dosis"]); ?> — <?php echo htmlspecialchars($m["indicacion"]); ?></div>
                                            </div>
                                            <?php if (has_col($colsMed, "stock_actual")): ?>
                                                <div><?php echo badge("Stock: ".$stxt." ({$m["stock_actual"]})", $scls); ?></div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="det-grid" style="margin-top:10px;">
                                            <div class="muted">Estado</div>
                                            <select name="det[<?php echo (int)$m["id"]; ?>][estado]">
                                                <option value="entregado">Entregado</option>
                                                <option value="parcial">Parcial</option>
                                                <option value="pendiente" selected>Pendiente</option>
                                            </select>
                                            <input type="text" name="det[<?php echo (int)$m["id"]; ?>][motivo]" placeholder="Motivo (ej: sin stock / cambio / pendiente)">
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mensaje">
                            No hay medicamentos registrados. Agrega medicamentos antes de registrar detalle.
                        </div>
                    <?php endif; ?>

                    <button class="btn" name="guardar_retiro">Registrar retiro</button>
                </form>
            </div>
        </div>

        <div class="sec box">
            <h3>Medicamentos (con stock)</h3>

            <?php if (empty($meds)): ?>
                <div class="mini">No hay medicamentos registrados.</div>
            <?php else: ?>
                <?php foreach($meds as $m): ?>
                    <?php [$stxt,$scls] = stock_tag($m["stock_actual"], $m["stock_minimo"]); ?>
                    <div class="medline">
                        <strong><?php echo htmlspecialchars($m["nombre"]); ?></strong><br>
                        <span class="mini">Dosis:</span> <?php echo htmlspecialchars($m["dosis"]); ?><br>
                        <span class="mini">Indicaciones:</span> <?php echo htmlspecialchars($m["indicacion"]); ?>

                        <?php if (has_col($colsMed, "stock_actual") && has_col($colsMed, "stock_minimo")): ?>
                            <div style="margin-top:8px;"><?php echo badge("Stock ".$stxt." ({$m["stock_actual"]})", $scls); ?></div>
                            <form method="POST" class="stock-form">
                                <input type="hidden" name="med_id" value="<?php echo (int)$m["id"]; ?>">
                                <input type="number" name="stock_actual" value="<?php echo (int)$m["stock_actual"]; ?>" min="0" placeholder="Stock actual">
                                <input type="number" name="stock_minimo" value="<?php echo (int)$m["stock_minimo"]; ?>" min="0" placeholder="Stock mínimo">
                                <button class="btn" name="actualizar_stock" style="width:auto;">Actualizar stock</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <hr style="margin:14px 0;">

            <h3>Agregar medicamento</h3>
            <form method="POST" class="block-primary" style="margin:0;">
                <input type="text" name="med_nombre" placeholder="Nombre medicamento" required>
                <input type="text" name="dosis" placeholder="Dosis / gramaje" required>
                <input type="text" name="indicacion" placeholder="Indicaciones" required>
                <button class="btn" name="guardar_medicamento">Guardar medicamento</button>
            </form>
        </div>

        <div class="sec box">
            <h3>Historial de retiros (trazabilidad + detalle)</h3>

            <?php if (empty($hist)): ?>
                <div class="mini">Sin retiros registrados.</div>
            <?php else: ?>
                <div class="table-scroll">
                    <table>
                        <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Días</th>
                            <th>Próximo</th>
                            <th>Obs</th>
                            <th>Registrado por</th>
                            <th>Registrado en</th>
                            <th>Detalle medicamentos</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($hist as $h): ?>
                            <?php
                            $prox = "";
                            if (!empty($h["fecha_retiro"]) && !empty($h["dias_cobertura"])) {
                                $prox = date("Y-m-d", strtotime($h["fecha_retiro"] . " +" . $h["dias_cobertura"] . " days"));
                            }
                            $por = $h["admin_nombre"] ? ($h["admin_nombre"].(!empty($h["admin_est"]) ? " — ".$h["admin_est"] : "")) : "(sin admin)";
                            $rid = (int)$h["id"];
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($h["fecha_retiro"]); ?></td>
                                <td><?php echo (int)$h["dias_cobertura"]; ?></td>
                                <td><?php echo htmlspecialchars($prox ?: "(no calculable)"); ?></td>
                                <td><?php echo htmlspecialchars($h["observacion"] ?? ""); ?></td>
                                <td><?php echo htmlspecialchars($por); ?></td>
                                <td><?php echo htmlspecialchars($h["creado_en"] ?? ""); ?></td>
                                <td>
                                    <?php if ($hasDetalle && !empty($histDet[$rid])): ?>
                                        <?php foreach($histDet[$rid] as $d): ?>
                                            <?php
                                            $est = $d["estado"] ?? "pendiente";
                                            $t = ($est==="entregado") ? "ok" : (($est==="parcial") ? "warn" : "bad");
                                            $label = ($est==="entregado") ? "Entregado" : (($est==="parcial") ? "Parcial" : "Pendiente");
                                            ?>
                                            <div style="margin-bottom:10px;">
                                                <span class="pill"><?php echo htmlspecialchars($d["nombre"] ?? ("Med #".$d["medicamento_id"])); ?></span>
                                                <?php echo badge($label, $t); ?>
                                                <?php if (!empty($d["motivo"])): ?>
                                                    <div class="muted"><?php echo htmlspecialchars($d["motivo"]); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="muted">(sin detalle)</div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <div class="btn-row" style="margin-top:16px;">
            <a class="btn btn-volver" href="panel.php">Volver al panel</a>
        </div>

    </div>
</main>
</body>
</html>

