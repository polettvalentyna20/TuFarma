<?php
$rut = $_GET["rut"] ?? "";
header("Location: tratamiento_nuevo.php?rut=" . urlencode($rut));
exit;

