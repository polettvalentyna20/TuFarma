<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/../data/audit.php";

$adminId = $_SESSION["admin_id"] ?? null;

// Registrar que se abrió auditoría
audit_log($conn, $adminId ? (int)$adminId : null, "VER_AUDITORIA", null, "Ingreso a vista auditoría");

function table_exists(mysqli $conn, string $table): bool {
    $res = $conn->query("SHOW TABLES LIKE '".$conn->real_escape_string($table)."'");
    return $res && $res->num_rows > 0;
}

$err = "";
$items = [];

if (!table_exists($conn, "auditoria")) {
    $err = "No existe la tabla auditoria (ejecuta el SQL de creación).";
} else {
    $sql = "
    SELECT au.creado_en, au.accion, au.rut, au.detalle, au.ip,
           a.nombre AS admin_nombre, a.establecimiento AS admin_est
    FROM auditoria au
    LEFT JOIN admins a ON a.id = au.admin_id
    ORDER BY au.id DESC
    LIMIT 200
  ";
    $res = $conn->query($sql);
    if ($res) $items = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Auditoría - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=auditoria-1">
    <style>
        .wrap{max-width:980px;width:100%}
        table{width:100%;border-collapse:collapse}
        th,td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left;vertical-align:top}
        thead tr{background:#f5f7fa}
        .pill{display:inline-block;padding:6px 10px;border-radius:999px;background:#eef2f7;font-weight:900;font-size:12px}
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Administrador — Auditoría del sistema</p>
</header>

<main class="container">
    <div class="card wrap">
        <h2 class="card-title">🧾 Auditoría</h2>
        <div class="mini" style="text-align:center;">Últimos 200 eventos (trazabilidad)</div>

        <?php if ($err): ?>
            <div class="error"><?php echo htmlspecialchars($err); ?></div>
        <?php else: ?>

            <?php if (empty($items)): ?>
                <div class="mensaje">Aún no hay eventos registrados.</div>
            <?php else: ?>
                <div style="overflow-x:auto;margin-top:12px;">
                    <table>
                        <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Acción</th>
                            <th>RUT</th>
                            <th>Detalle</th>
                            <th>Admin</th>
                            <th>IP</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($items as $it): ?>
                            <?php
                            $adminTxt = $it["admin_nombre"]
                                    ? ($it["admin_nombre"].(!empty($it["admin_est"]) ? " — ".$it["admin_est"] : ""))
                                    : "(sin admin)";
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($it["creado_en"] ?? ""); ?></td>
                                <td><span class="pill"><?php echo htmlspecialchars($it["accion"] ?? ""); ?></span></td>
                                <td><?php echo htmlspecialchars($it["rut"] ?? ""); ?></td>
                                <td><?php echo htmlspecialchars($it["detalle"] ?? ""); ?></td>
                                <td><?php echo htmlspecialchars($adminTxt); ?></td>
                                <td><?php echo htmlspecialchars($it["ip"] ?? ""); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

        <?php endif; ?>

        <div class="btn-row" style="margin-top:16px;">
            <a class="btn btn-volver" href="panel.php">Volver al panel</a>
        </div>
    </div>
</main>

</body>
</html>

