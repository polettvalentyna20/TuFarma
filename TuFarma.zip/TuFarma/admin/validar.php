<?php
// TuFarma/admin/validar.php

if (session_status() === PHP_SESSION_NONE) session_start();

require __DIR__ . "/../data/conexion.php";

$usuario = trim($_POST["usuario"] ?? "");
$clave   = trim($_POST["clave"] ?? "");

if ($usuario === "" || $clave === "") {
    header("Location: login.php?err=" . urlencode("Completa usuario y contraseña."));
    exit;
}

try {
    $stmt = $conn->prepare("
    SELECT id, usuario, clave_hash, nombre, establecimiento, activo
    FROM admins
    WHERE usuario = ?
    LIMIT 1
  ");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();

    if (!$admin) {
        header("Location: login.php?err=" . urlencode("Usuario no encontrado."));
        exit;
    }

    if ((int)$admin["activo"] !== 1) {
        header("Location: login.php?err=" . urlencode("Usuario inactivo. Contacta al administrador."));
        exit;
    }

    // Verificación correcta con hash
    if (!password_verify($clave, $admin["clave_hash"])) {
        header("Location: login.php?err=" . urlencode("Contraseña incorrecta."));
        exit;
    }

    // Login OK
    $_SESSION["admin_id"] = (int)$admin["id"];
    $_SESSION["admin_usuario"] = $admin["usuario"];
    $_SESSION["admin_nombre"] = $admin["nombre"];
    $_SESSION["admin_establecimiento"] = $admin["establecimiento"];

    header("Location: panel.php");
    exit;

} catch (Throwable $e) {
    header("Location: login.php?err=" . urlencode("Error del sistema: " . $e->getMessage()));
    exit;
}

