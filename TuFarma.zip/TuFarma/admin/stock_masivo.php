<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";

// Auditoría (si existe el helper)
$auditPath = __DIR__ . "/../data/audit.php";
if (file_exists($auditPath)) include $auditPath;

$adminId = $_SESSION["admin_id"] ?? null;

function table_exists(mysqli $conn, string $table): bool {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}
function get_columns(mysqli $conn, string $table): array {
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($res) while ($row = $res->fetch_assoc()) $cols[] = $row["Field"];
    return $cols;
}
function has_col(array $cols, string $col): bool { return in_array($col, $cols, true); }

$err = "";
$ok = "";

$q = trim($_GET["q"] ?? "");
$items = [];

if (!table_exists($conn, "medicamentos")) {
    $err = "No existe la tabla medicamentos.";
} else {
    $cols = get_columns($conn, "medicamentos");
    if (!has_col($cols, "stock_actual") || !has_col($cols, "stock_minimo")) {
        $err = "Tu tabla medicamentos no tiene columnas stock_actual y stock_minimo.";
    }
}

/* =========================
   1) CREAR MEDICAMENTO NUEVO
   ========================= */
if (!$err && $_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["crear_medicamento"])) {
    $nombre = trim($_POST["nuevo_nombre"] ?? "");
    $sa = (int)($_POST["nuevo_stock_actual"] ?? 0);
    $sm = (int)($_POST["nuevo_stock_minimo"] ?? 0);

    if ($nombre === "") {
        $err = "Ingresa el nombre del medicamento.";
    } else {
        if ($sa < 0) $sa = 0;
        if ($sm < 0) $sm = 0;

        // Evitar duplicados por nombre (comparación simple case-insensitive)
        $st = $conn->prepare("SELECT id FROM medicamentos WHERE LOWER(nombre)=LOWER(?) LIMIT 1");
        $st->bind_param("s", $nombre);
        $st->execute();
        $ex = $st->get_result()->fetch_assoc();

        if ($ex) {
            $err = "Ese medicamento ya existe en la lista. (No se creó duplicado)";
            if (function_exists("audit_log")) {
                audit_log($conn, $adminId ? (int)$adminId : null, "MEDICAMENTO_DUPLICADO", null, "Nombre: ".$nombre);
            }
        } else {
            $st2 = $conn->prepare("INSERT INTO medicamentos (nombre, stock_actual, stock_minimo) VALUES (?, ?, ?)");
            $st2->bind_param("sii", $nombre, $sa, $sm);
            $st2->execute();

            $ok = "✅ Medicamento creado: ".$nombre;

            if (function_exists("audit_log")) {
                audit_log($conn, $adminId ? (int)$adminId : null, "CREAR_MEDICAMENTO", null, "Nombre: $nombre | Stock:$sa | Min:$sm");
            }

            // Para que aparezca altiro, refrescamos la lista sin perder búsqueda
            header("Location: stock_masivo.php" . ($q ? ("?q=".urlencode($q)) : ""));
            exit;
        }
    }
}

/* ======================
   2) GUARDAR MASIVO STOCK
   ====================== */
if (!$err && $_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["guardar_masivo"])) {
    $ids = $_POST["id"] ?? [];
    $stock_actual = $_POST["stock_actual"] ?? [];
    $stock_minimo = $_POST["stock_minimo"] ?? [];

    if (!is_array($ids) || !is_array($stock_actual) || !is_array($stock_minimo)) {
        $err = "Datos inválidos.";
    } else {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE medicamentos SET stock_actual=?, stock_minimo=? WHERE id=?");
            $updated = 0;

            foreach ($ids as $idx => $idVal) {
                $id = (int)$idVal;
                if ($id <= 0) continue;

                $sa = isset($stock_actual[$idx]) ? (int)$stock_actual[$idx] : 0;
                $sm = isset($stock_minimo[$idx]) ? (int)$stock_minimo[$idx] : 0;

                if ($sa < 0) $sa = 0;
                if ($sm < 0) $sm = 0;

                $stmt->bind_param("iii", $sa, $sm, $id);
                $stmt->execute();
                $updated++;
            }

            $conn->commit();

            $ok = "✅ Stock actualizado para $updated medicamento(s).";

            if (function_exists("audit_log")) {
                audit_log($conn, $adminId ? (int)$adminId : null, "STOCK_MASIVO_GUARDAR", null, "Actualizados: $updated");
            }

        } catch (Throwable $e) {
            $conn->rollback();
            $err = "Error al guardar: " . $e->getMessage();
        }
    }
}

/* ======================
   3) CARGAR LISTA
   ====================== */
if (!$err) {
    if ($q !== "") {
        $like = "%".$q."%";
        $st = $conn->prepare("
      SELECT id, nombre, stock_actual, stock_minimo
      FROM medicamentos
      WHERE nombre LIKE ?
      ORDER BY nombre ASC
      LIMIT 600
    ");
        $st->bind_param("s", $like);
        $st->execute();
        $items = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    } else {
        $res = $conn->query("
      SELECT id, nombre, stock_actual, stock_minimo
      FROM medicamentos
      ORDER BY nombre ASC
      LIMIT 600
    ");
        if ($res) $items = $res->fetch_all(MYSQLI_ASSOC);
    }

    if (function_exists("audit_log")) {
        audit_log($conn, $adminId ? (int)$adminId : null, "VER_STOCK_MASIVO", null, $q ? ("Busqueda: ".$q) : "Vista general");
    }
}

function stock_badge($sa, $sm){
    $sa = (int)$sa; $sm = (int)$sm;
    if ($sa <= 0) return "<span class='badge bad'>Sin stock</span>";
    if ($sa <= $sm) return "<span class='badge warn'>Crítico</span>";
    return "<span class='badge ok'>OK</span>";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ingreso Masivo de Stock - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=stock-masivo-2">
    <style>
        .wrap{max-width:980px;width:100%}
        .topbar{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center}
        .search{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:12px}
        .search input{max-width:420px;margin:0}
        .search .btn{width:auto;margin:0;min-width:140px}

        table{width:100%;border-collapse:collapse}
        th,td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left;vertical-align:middle}
        thead tr{background:#f5f7fa}

        .cell-input{width:140px; margin:0; padding:10px 10px; border-radius:12px}

        .sticky-actions{
            position:sticky; bottom:0;
            background:rgba(255,255,255,.92);
            backdrop-filter: blur(8px);
            padding:12px; border-top:1px solid #eef2f7;
            margin-top:12px; border-radius:14px
        }
        .actions{display:flex;gap:12px;flex-wrap:wrap;justify-content:center}
        .actions .btn{width:auto;min-width:220px;margin:0}

        .grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
        @media(max-width:900px){.grid{grid-template-columns:1fr}}
        .box{border:1px solid var(--border);border-radius:16px;padding:16px;background:#fff}
        .muted{color:var(--muted);font-size:13px}
        .inline-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
        @media(max-width:900px){.inline-3{grid-template-columns:1fr}}
        .inline-3 input{margin:0}
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Farmacia — Ingreso Masivo de Stock</p>
</header>

<main class="container">
    <div class="card wrap">

        <div class="topbar">
            <div>
                <h2 class="card-title" style="text-align:left;margin:0;">📦 Ingreso masivo de stock</h2>
                <div class="mini">Edita stock actual y stock mínimo y guarda todo de una vez.</div>
            </div>
            <a class="btn btn-volver" style="width:auto;min-width:200px;" href="panel.php">Volver al panel</a>
        </div>

        <?php if ($err): ?>
            <div class="error"><?php echo htmlspecialchars($err); ?></div>
        <?php endif; ?>
        <?php if ($ok): ?>
            <div class="ok"><?php echo htmlspecialchars($ok); ?></div>
        <?php endif; ?>

        <?php if (!$err): ?>

            <div class="grid">
                <!-- Crear medicamento -->
                <div class="box">
                    <h3 style="margin:0;">➕ Crear medicamento (Farmacia)</h3>
                    <div class="muted" style="margin-top:6px;">
                        Crea medicamentos aunque no estén asignados a pacientes. Puedes dejar stock en 0 si aún no hay ingreso.
                    </div>

                    <form method="POST" style="margin-top:12px;">
                        <input type="text" name="nuevo_nombre" placeholder="Nombre (ej: Losartan 50 mg)" required>

                        <div class="inline-3" style="margin-top:10px;">
                            <input type="number" name="nuevo_stock_actual" min="0" value="0" placeholder="Stock actual">
                            <input type="number" name="nuevo_stock_minimo" min="0" value="30" placeholder="Stock mínimo">
                            <button class="btn" name="crear_medicamento" type="submit" style="margin:0;">Crear</button>
                        </div>
                    </form>

                    <div class="muted" style="margin-top:10px;">
                        Nota: evita duplicados por nombre (el sistema no crea 2 iguales).
                    </div>
                </div>

                <!-- Buscador -->
                <div class="box">
                    <h3 style="margin:0;">🔎 Buscar en lista</h3>
                    <div class="muted" style="margin-top:6px;">Busca por nombre para editar rápido (ej: metformina).</div>

                    <form class="search" method="GET" action="stock_masivo.php" style="margin-top:12px;">
                        <input type="text" name="q" placeholder="Buscar medicamento..." value="<?php echo htmlspecialchars($q); ?>">
                        <button class="btn" type="submit">Buscar</button>
                        <?php if ($q !== ""): ?>
                            <a class="btn btn-volver" style="width:auto;min-width:140px;" href="stock_masivo.php">Limpiar</a>
                        <?php endif; ?>
                    </form>

                    <div class="muted" style="margin-top:8px;">
                        Tip: primero define el <strong>stock mínimo</strong> (umbral) y luego el stock actual.
                    </div>
                </div>
            </div>

            <?php if (empty($items)): ?>
                <div class="mensaje" style="margin-top:12px;">No hay medicamentos para mostrar.</div>
            <?php else: ?>
                <form method="POST" action="stock_masivo.php<?php echo $q ? ("?q=".urlencode($q)) : ""; ?>">
                    <div style="overflow-x:auto;margin-top:12px;">
                        <table>
                            <thead>
                            <tr>
                                <th>Medicamento</th>
                                <th>Estado</th>
                                <th>Stock actual</th>
                                <th>Stock mínimo</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($items as $i => $m): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($m["nombre"]); ?></strong></td>
                                    <td><?php echo stock_badge($m["stock_actual"], $m["stock_minimo"]); ?></td>

                                    <td>
                                        <input type="hidden" name="id[]" value="<?php echo (int)$m["id"]; ?>">
                                        <input class="cell-input" type="number" name="stock_actual[]" min="0" value="<?php echo (int)$m["stock_actual"]; ?>">
                                    </td>
                                    <td>
                                        <input class="cell-input" type="number" name="stock_minimo[]" min="0" value="<?php echo (int)$m["stock_minimo"]; ?>">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="sticky-actions">
                        <div class="actions">
                            <button class="btn" name="guardar_masivo" type="submit">💾 Guardar cambios</button>
                            <a class="btn btn-secondary" href="stock_critico.php" style="min-width:220px;">⚠️ Ver stock crítico</a>
                        </div>
                        <div class="mini" style="text-align:center;margin-top:8px;">
                            Cambios se guardan en lote. Recarga con Ctrl+F5 si el navegador cachea.
                        </div>
                    </div>
                </form>
            <?php endif; ?>

        <?php endif; ?>

    </div>
</main>

</body>
</html>
