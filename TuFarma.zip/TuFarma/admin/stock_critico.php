<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/../data/audit.php";

$adminId = $_SESSION["admin_id"] ?? null;

function get_columns(mysqli $conn, string $table): array {
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($res) while ($row = $res->fetch_assoc()) $cols[] = $row["Field"];
    return $cols;
}
function has_col(array $cols, string $col): bool { return in_array($col, $cols, true); }

$err = "";
$cols = [];
if ($conn->query("SHOW TABLES LIKE 'medicamentos'")->num_rows === 0) {
    $err = "No existe la tabla medicamentos.";
} else {
    $cols = get_columns($conn, "medicamentos");
    if (!has_col($cols, "stock_actual") || !has_col($cols, "stock_minimo")) {
        $err = "Tu tabla medicamentos no tiene columnas stock_actual y stock_minimo.";
    }
}

// Auditoría: entrar al reporte
audit_log($conn, $adminId ? (int)$adminId : null, "VER_STOCK_CRITICO", null, "Ingreso a reporte de stock crítico");

$items = [];
if (!$err) {
    $sql = "
    SELECT id, nombre, stock_actual, stock_minimo,
           CASE
             WHEN stock_actual <= 0 THEN 'SIN_STOCK'
             WHEN stock_actual <= stock_minimo THEN 'CRITICO'
             ELSE 'OK'
           END AS nivel
    FROM medicamentos
    WHERE stock_actual <= stock_minimo
    ORDER BY stock_actual ASC, nombre ASC
  ";
    $res = $conn->query($sql);
    if ($res) $items = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Stock Crítico - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=stock-critico-1">
    <style>
        .wrap{max-width:900px;width:100%}
        table{width:100%;border-collapse:collapse}
        th,td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left}
        thead tr{background:#f5f7fa}
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Administrador — Reporte de Stock Crítico</p>
</header>

<main class="container">
    <div class="card wrap">
        <h2 class="card-title">📦 Stock crítico / sin stock</h2>
        <div class="mini" style="text-align:center;">Medicamentos con stock ≤ mínimo (prioridad farmacia)</div>

        <?php if ($err): ?>
            <div class="error"><?php echo htmlspecialchars($err); ?></div>
        <?php else: ?>

            <?php if (empty($items)): ?>
                <div class="ok">✅ No hay medicamentos bajo mínimo. Stock en rango.</div>
            <?php else: ?>
                <div class="mensaje">⚠️ Atención: estos medicamentos están en nivel crítico o sin stock.</div>

                <div style="overflow-x:auto;margin-top:12px;">
                    <table>
                        <thead>
                        <tr>
                            <th>Medicamento</th>
                            <th>Stock actual</th>
                            <th>Stock mínimo</th>
                            <th>Estado</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($items as $it): ?>
                            <?php
                            $nivel = $it["nivel"];
                            if ($nivel === "SIN_STOCK") { $b = "<span class='badge bad'>Sin stock</span>"; }
                            else { $b = "<span class='badge warn'>Crítico</span>"; }
                            ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($it["nombre"]); ?></strong></td>
                                <td><?php echo (int)$it["stock_actual"]; ?></td>
                                <td><?php echo (int)$it["stock_minimo"]; ?></td>
                                <td><?php echo $b; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

        <?php endif; ?>

        <div class="btn-row" style="margin-top:16px;">
            <a class="btn btn-volver" href="panel.php">Volver al panel</a>
        </div>
    </div>
</main>

</body>
</html>

