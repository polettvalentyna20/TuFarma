<?php
// TuFarma/admin/admin_nuevo.php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";

// auditoría opcional
$auditPath = __DIR__ . "/../data/audit.php";
if (file_exists($auditPath)) include $auditPath;

$adminId = $_SESSION["admin_id"] ?? null;

$err = "";
$ok  = "";

function table_exists(mysqli $conn, string $table): bool {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}

function get_columns(mysqli $conn, string $table): array {
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($res) while ($row = $res->fetch_assoc()) $cols[] = $row["Field"];
    return $cols;
}
function has_col(array $cols, string $col): bool { return in_array($col, $cols, true); }

try {
    // Validación de tabla
    if (!table_exists($conn, "admins")) {
        $err = "❌ No existe la tabla admins en la BD tufarma.";
    } else {
        $cols = get_columns($conn, "admins");
        $needed = ["usuario","clave_hash","nombre","establecimiento","activo"];
        foreach ($needed as $c) {
            if (!has_col($cols, $c)) {
                $err = "❌ Falta columna en admins: <strong>$c</strong>";
                break;
            }
        }
    }

    // Procesar POST
    if (!$err && $_SERVER["REQUEST_METHOD"] === "POST") {
        $usuario = trim($_POST["usuario"] ?? "");
        $clave   = trim($_POST["clave"] ?? "");
        $nombre  = trim($_POST["nombre"] ?? "");
        $est     = trim($_POST["establecimiento"] ?? "");

        if ($usuario === "" || $clave === "" || $nombre === "" || $est === "") {
            $err = "Completa todos los campos.";
        } elseif (strlen($usuario) < 3) {
            $err = "El usuario debe tener al menos 3 caracteres.";
        } elseif (strlen($clave) < 4) {
            $err = "La contraseña debe tener al menos 4 caracteres.";
        } else {
            // duplicado
            $st = $conn->prepare("SELECT id FROM admins WHERE usuario = ? LIMIT 1");
            $st->bind_param("s", $usuario);
            $st->execute();
            $ex = $st->get_result()->fetch_assoc();

            if ($ex) {
                $err = "Ese usuario ya existe. Elige otro (ej: farmacia02).";
                if (function_exists("audit_log")) {
                    audit_log($conn, $adminId ? (int)$adminId : null, "ADMIN_DUPLICADO", null, "Usuario: ".$usuario);
                }
            } else {
                $hash = password_hash($clave, PASSWORD_DEFAULT);

                $st2 = $conn->prepare("
          INSERT INTO admins (usuario, clave_hash, nombre, establecimiento, activo)
          VALUES (?, ?, ?, ?, 1)
        ");
                $st2->bind_param("ssss", $usuario, $hash, $nombre, $est);
                $st2->execute();

                $ok = "✅ Administrador creado correctamente: <strong>".htmlspecialchars($usuario)."</strong>";

                if (function_exists("audit_log")) {
                    audit_log($conn, $adminId ? (int)$adminId : null, "CREAR_ADMIN", null, "Usuario:$usuario | Nombre:$nombre | Est:$est");
                }
            }
        }
    }

} catch (Throwable $e) {
    $err = "❌ Error del sistema: " . htmlspecialchars($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar administrador - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=admin-nuevo-debug-1">
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Administrador — Agregar administrador</p>
</header>

<main class="container">
    <div class="card card-medium">
        <h2 class="card-title">➕ Agregar administrador</h2>

        <?php if ($err): ?>
            <div class="error"><?php echo $err; ?></div>
        <?php endif; ?>

        <?php if ($ok): ?>
            <div class="ok"><?php echo $ok; ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="block-primary">
            <input type="text" name="usuario" placeholder="Usuario (ej: farmacia01)" required>
            <input type="password" name="clave" placeholder="Contraseña" required>
            <input type="text" name="nombre" placeholder="Nombre completo" required>
            <input type="text" name="establecimiento" placeholder="Establecimiento (ej: CESFAM Santa Amalia)" required>
            <button class="btn" type="submit">Guardar administrador</button>
        </form>

        <div class="btn-row">
            <a class="btn btn-volver" href="panel.php">Volver</a>
        </div>

        <div class="mini" style="text-align:center;margin-top:10px;">
            Si aprietas “Guardar” y no pasa nada, aquí arriba debe salir el motivo (error o confirmación).
        </div>
    </div>
</main>

</body>
</html>
