<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/_log.php";

$rut = trim($_GET["rut"] ?? "");
if ($rut === "") { header("Location: panel.php"); exit; }

$stmt = $conn->prepare("SELECT rut, nombre FROM pacientes WHERE rut=?");
$stmt->bind_param("s", $rut);
$stmt->execute();
$pac = $stmt->get_result()->fetch_assoc();
if (!$pac) die("Paciente no encontrado");

$err = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fecha = $_POST["fecha_retiro"] ?? "";
    $dias = (int)($_POST["dias_cobertura"] ?? 30);
    $obs = trim($_POST["observacion"] ?? "");

    if ($fecha === "" || $dias <= 0) {
        $err = "Ingresa fecha y días válidos.";
    } else {
        $stmt = $conn->prepare("INSERT INTO retiros (rut, fecha_retiro, dias_cobertura, observacion) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $rut, $fecha, $dias, $obs);
        if ($stmt->execute()) {
            log_accion($conn, "RETIRO_CREATE", $rut, "Retiro={$fecha} cobertura={$dias}d obs={$obs}");
            header("Location: ver_paciente.php?rut=" . urlencode($rut));
            exit;
        } else {
            $err = "Error guardando retiro.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar retiro - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Registrar retiro — <?php echo htmlspecialchars($pac["nombre"]); ?></p>
</header>

<main class="container">
    <div class="card">
        <h2 class="card-title">Nuevo retiro</h2>
        <?php if ($err): ?><div class="error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

        <form method="POST">
            <input type="date" name="fecha_retiro" required>
            <input type="text" name="dias_cobertura" placeholder="Días de cobertura (ej: 30)" value="30" required>
            <input type="text" name="observacion" placeholder="Observación (opcional)">
            <button class="btn" type="submit">Guardar retiro</button>
        </form>

        <a class="btn btn-volver" href="ver_paciente.php?rut=<?php echo urlencode($rut); ?>">Volver</a>
    </div>
</main>
</body>
</html>
