<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";

$rut = $_GET["rut"] ?? "";
if ($rut === "") {
    header("Location: panel.php");
    exit;
}

$stmt = $conn->prepare("SELECT rut, nombre FROM pacientes WHERE rut=?");
$stmt->bind_param("s", $rut);
$stmt->execute();
$paciente = $stmt->get_result()->fetch_assoc();

if (!$paciente) {
    die("Paciente no encontrado");
}

$mensaje = "";

// Guardar medicamento
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = trim($_POST["nombre"] ?? "");
    $dosis = trim($_POST["dosis"] ?? "");
    $indicacion = trim($_POST["indicacion"] ?? "");

    if ($nombre === "" || $dosis === "" || $indicacion === "") {
        $mensaje = "Completa todos los campos.";
    } else {
        // Crear medicamento
        $stmt = $conn->prepare("INSERT INTO medicamentos (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $med_id = $conn->insert_id;

        // Asociar al paciente
        $stmt = $conn->prepare("
      INSERT INTO tratamientos (rut, medicamento_id, dosis, indicacion)
      VALUES (?, ?, ?, ?)
    ");
        $stmt->bind_param("siss", $rut, $med_id, $dosis, $indicacion);
        $stmt->execute();

        header("Location: ver_paciente.php?rut=" . urlencode($rut));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar medicamento - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<header class="header">
    <h1>💊 TuFarma</h1>
    <p>Agregar medicamento</p>
</header>

<main class="container">
    <div class="card">
        <h2 class="card-title">
            Paciente: <?php echo htmlspecialchars($paciente["nombre"]); ?>
        </h2>

        <?php if ($mensaje): ?>
            <div class="error"><?php echo htmlspecialchars($mensaje); ?></div>
        <?php endif; ?>

        <div class="block-primary">
            <form method="POST">
                <input type="text" name="nombre" placeholder="Nombre del medicamento" required>
                <input type="text" name="dosis" placeholder="Dosis / gramaje" required>
                <input type="text" name="indicacion" placeholder="Indicaciones" required>
                <button class="btn">Guardar medicamento</button>
            </form>
        </div>

        <div class="block-tertiary">
            <a class="btn btn-volver" href="ver_paciente.php?rut=<?php echo urlencode($rut); ?>">
                Volver a la ficha
            </a>
        </div>
    </div>
</main>

</body>
</html>
