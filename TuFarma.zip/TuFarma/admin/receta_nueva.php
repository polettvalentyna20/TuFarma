<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/_log.php";

$rut = trim($_GET["rut"] ?? "");
if ($rut === "") { header("Location: panel.php"); exit; }

$stmt = $conn->prepare("SELECT rut, nombre FROM pacientes WHERE rut=?");
$stmt->bind_param("s", $rut);
$stmt->execute();
$pac = $stmt->get_result()->fetch_assoc();
if (!$pac) die("Paciente no encontrado");

$err = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $desde = $_POST["vigente_desde"] ?? "";
    $hasta = $_POST["vigente_hasta"] ?? "";
    $obs = trim($_POST["observacion"] ?? "");

    if ($desde === "" || $hasta === "") {
        $err = "Debes ingresar desde/hasta.";
    } elseif (strtotime($hasta) < strtotime($desde)) {
        $err = "La fecha 'hasta' no puede ser menor que 'desde'.";
    } else {
        $stmt = $conn->prepare("INSERT INTO recetas (rut, vigente_desde, vigente_hasta, observacion) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $rut, $desde, $hasta, $obs);
        if ($stmt->execute()) {
            log_accion($conn, "RECETA_CREATE", $rut, "Receta {$desde} a {$hasta}. Obs: {$obs}");
            header("Location: ver_paciente.php?rut=" . urlencode($rut));
            exit;
        } else {
            $err = "Error al guardar receta.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva receta - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Nueva receta — <?php echo htmlspecialchars($pac["nombre"]); ?></p>
</header>

<main class="container">
    <div class="card">
        <h2 class="card-title">Registrar receta</h2>
        <?php if ($err): ?><div class="error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

        <form method="POST">
            <input type="date" name="vigente_desde" required>
            <input type="date" name="vigente_hasta" required>
            <input type="text" name="observacion" placeholder="Observación (opcional)">
            <button class="btn" type="submit">Guardar receta</button>
        </form>

        <a class="btn btn-volver" href="ver_paciente.php?rut=<?php echo urlencode($rut); ?>">Volver</a>
    </div>
</main>
</body>
</html>

