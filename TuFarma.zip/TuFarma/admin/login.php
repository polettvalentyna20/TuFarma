<?php
// TuFarma/admin/login.php

if (session_status() === PHP_SESSION_NONE) session_start();

if (!empty($_SESSION["admin_id"])) {
    header("Location: panel.php");
    exit;
}

$err = $_GET["err"] ?? "";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login Administrador - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=auth-unified-1">

    <!-- Forzado para que SIEMPRE sea mismo tamaño -->
    <style>
        .auth-card{ max-width:520px !important; width:100% !important; margin:0 auto !important; }
        .container{ display:flex !important; justify-content:center !important; padding:18px 14px 36px !important; }
    </style>
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Acceso Administrador</p>
</header>

<main class="container">
    <div class="card auth-card">
        <h2 class="card-title">Ingresar</h2>

        <?php if ($err): ?>
            <div class="error"><?php echo htmlspecialchars($err); ?></div>
        <?php endif; ?>

        <form method="POST" action="validar.php" class="block-primary">
            <input type="text" name="usuario" placeholder="Usuario" required autocomplete="username">
            <input type="password" name="clave" placeholder="Contraseña" required autocomplete="current-password">
            <button class="btn" type="submit">Acceder</button>
        </form>

        <div class="btn-row">
            <a class="btn btn-volver" href="../index.php">Volver al inicio</a>
        </div>
    </div>
</main>

</body>
</html>
