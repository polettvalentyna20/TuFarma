<?php
// Logger de auditoría CESFAM
// Requiere: session_start() ya activo y $conn disponible.
function log_accion(mysqli $conn, string $accion, ?string $rutPaciente = null, ?string $detalle = null): void {
    $adminUsuario = $_SESSION["admin"] ?? "desconocido";
    $adminNombre = $_SESSION["admin_nombre"] ?? "Administrador";
    $adminEst = $_SESSION["admin_establecimiento"] ?? "CESFAM Santa Amalia";

    $stmt = $conn->prepare("
    INSERT INTO acciones_log (admin_usuario, admin_nombre, admin_establecimiento, accion, rut_paciente, detalle)
    VALUES (?, ?, ?, ?, ?, ?)
  ");
    $stmt->bind_param("ssssss", $adminUsuario, $adminNombre, $adminEst, $accion, $rutPaciente, $detalle);
    $stmt->execute();
}

