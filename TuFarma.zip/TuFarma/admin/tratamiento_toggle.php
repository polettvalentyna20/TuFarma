<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/_log.php";

$id = (int)($_GET["id"] ?? 0);
$rut = trim($_GET["rut"] ?? "");
$to = (int)($_GET["to"] ?? 0);

if ($id <= 0 || $rut === "" || ($to !== 0 && $to !== 1)) {
    header("Location: panel.php");
    exit;
}

$stmt = $conn->prepare("UPDATE tratamientos SET activo=? WHERE id=?");
$stmt->bind_param("ii", $to, $id);
$stmt->execute();

$detalle = $to === 1 ? "Reactivó tratamiento ID={$id}" : "Desactivó tratamiento ID={$id}";
log_accion($conn, "TRATAMIENTO_TOGGLE", $rut, $detalle);

header("Location: ver_paciente.php?rut=" . urlencode($rut));
exit;

