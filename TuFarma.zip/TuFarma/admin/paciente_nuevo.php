<?php
include __DIR__ . "/_guard.php";
include __DIR__ . "/../data/conexion.php";
include __DIR__ . "/../data/rut.php";
include __DIR__ . "/../data/audit.php";

$adminId = $_SESSION["admin_id"] ?? null;

$err = "";
$ok = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $rut_in = trim($_POST["rut"] ?? "");
    $nombre = trim($_POST["nombre"] ?? "");

    if ($rut_in === "" || $nombre === "") {
        $err = "Completa RUT y nombre.";
    } elseif (!rut_is_valid($rut_in)) {
        $err = "RUT inválido (DV incorrecto).";
    } else {
        $rut_norm = rut_normalize($rut_in);
        $rut_comp = rut_compact($rut_norm);

        $sql = "SELECT rut FROM pacientes
            WHERE REPLACE(REPLACE(rut,'.',''),'-','') = ?
            LIMIT 1";
        $st = $conn->prepare($sql);
        $st->bind_param("s", $rut_comp);
        $st->execute();
        $existe = $st->get_result()->fetch_assoc();

        if ($existe) {
            $err = "Ese RUT ya está registrado como paciente.";
            audit_log($conn, $adminId ? (int)$adminId : null, "PACIENTE_DUPLICADO", $rut_norm, "Intento duplicado");
        } else {
            $st2 = $conn->prepare("INSERT INTO pacientes (rut, nombre) VALUES (?, ?)");
            $st2->bind_param("ss", $rut_norm, $nombre);
            $st2->execute();

            $ok = "Paciente guardado correctamente.";
            audit_log($conn, $adminId ? (int)$adminId : null, "CREAR_PACIENTE", $rut_norm, "Nombre: ".$nombre);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar paciente - TuFarma</title>
    <link rel="stylesheet" href="../css/estilos.css?v=paciente-nuevo-audit-1">
</head>
<body>

<header class="header">
    <img src="https://img.icons8.com/color/96/000000/ambulance.png" class="header-img" alt="Salud">
    <h1>💊 TuFarma</h1>
    <p>Administrador — Agregar paciente</p>
</header>

<main class="container">
    <div class="card card-medium">
        <h2 class="card-title">➕ Agregar paciente</h2>

        <?php if ($err): ?><div class="error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
        <?php if ($ok): ?><div class="ok"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>

        <form method="POST" class="block-primary">
            <input type="text" name="rut" placeholder="RUT (ej: 12.345.678-9)" required>
            <input type="text" name="nombre" placeholder="Nombre completo" required>
            <button class="btn" type="submit">Guardar paciente</button>
        </form>

        <div class="btn-row">
            <a class="btn btn-volver" href="panel.php">Volver</a>
        </div>
    </div>
</main>

</body>
</html>

