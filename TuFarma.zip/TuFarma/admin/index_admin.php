<?php
session_start();
if(!isset($_SESSION['usuario']) || $_SESSION['tipo'] != "admin"){
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Administrador - TuFarma</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header class="header">
    <h1>💊 Panel Administrador</h1>
    <span><?php echo $_SESSION['usuario']; ?></span>
    <a href="logout.php" class="btn-logout">Cerrar sesión</a>
</header>

<main class="container">
    <div class="card">
        <h2>Bienvenido Administrador</h2>
        <p>Aquí puedes gestionar productos, usuarios y ventas.</p>
        <div class="acciones">
            <a href="#" class="btn">📦 Productos</a>
            <a href="#" class="btn">👤 Usuarios</a>
            <a href="#" class="btn">💰 Ventas</a>
        </div>
    </div>
</main>
</body>
</html>

