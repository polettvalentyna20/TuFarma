function validarRut(rut) {
    rut = rut.replace(/\./g, "").replace("-", "");
    if (rut.length < 8) return false;

    const cuerpo = rut.slice(0, -1);
    let dv = rut.slice(-1).toUpperCase();

    let suma = 0;
    let multiplo = 2;

    for (let i = cuerpo.length - 1; i >= 0; i--) {
        suma += multiplo * cuerpo[i];
        multiplo = multiplo < 7 ? multiplo + 1 : 2;
    }

    const dvEsperado = 11 - (suma % 11);
    const dvFinal =
        dvEsperado === 11 ? "0" :
            dvEsperado === 10 ? "K" :
                dvEsperado.toString();

    return dv === dvFinal;
}

function crearPaciente() {
    const rut = document.getElementById("nuevoRut").value.trim();
    const nombre = document.getElementById("nuevoNombre").value.trim();
    const resultado = document.getElementById("resultadoCrear");

    if (!rut || !nombre) {
        resultado.textContent = "Todos los campos son obligatorios";
        resultado.className = "error";
        return;
    }

    if (!validarRut(rut)) {
        resultado.textContent = "RUT inválido";
        resultado.className = "error";
        return;
    }

    fetch("crear_paciente.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `rut=${encodeURIComponent(rut)}&nombre=${encodeURIComponent(nombre)}`
    })
        .then(res => res.text())
        .then(data => {
            resultado.textContent = data;
            resultado.className = data.includes("exitosamente") ? "success" : "error";
        })
        .catch(() => {
            resultado.textContent = "Error de conexión";
            resultado.className = "error";
        });
}


